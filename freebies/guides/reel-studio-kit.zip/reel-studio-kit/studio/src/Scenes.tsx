// Starter scene for Reel Studio Kit. Claude rewrites this file for every new reel.
// Building blocks: Beat (one section), Pop (spring pop-in), Card (white card), Stamp (slam text), Caption (word-synced, from data.json).
import React from 'react';
import {AbsoluteFill, useCurrentFrame, spring} from 'remotion';
import '@fontsource/anton/400.css';
import {SANS, FPS, useT} from './kit';
import {L, O3} from './motion';
import {LiveBg} from './LiveBg';
import data from './data.json';

const INK = '#1C1A17', ROSE = '#FF2D95', CER = '#007BA7', MUTE = '#8C8780';
const DISP = "'Anton', 'Inter', sans-serif";
const useSp = (at: number, cfg = {damping: 14, stiffness: 160}) => { const f = useCurrentFrame(); return f < at * FPS ? 0 : spring({frame: f - at * FPS, fps: FPS, config: cfg}); };
const Pop: React.FC<{at: number; children: React.ReactNode}> = ({at, children}) => { const s = useSp(at); if (s <= 0) return null; return <div style={{transform: `translateY(${(1 - s) * 22}px) scale(${0.8 + 0.2 * s})`, opacity: Math.min(1, s * 2), filter: `blur(${Math.max(0, 1 - s * 1.5) * 8}px)`}}>{children}</div>; };
const Abs: React.FC<{top: number; children: React.ReactNode}> = ({top, children}) => <div style={{position: 'absolute', top, left: 0, right: 0, display: 'flex', justifyContent: 'center'}}>{children}</div>;
const Beat: React.FC<{a: number; b: number; children: React.ReactNode}> = ({a, b, children}) => { const t = useT(); if (t < a || t >= b) return null; const o = L(t, b - 0.12, b, 1, 0); return <AbsoluteFill style={{opacity: o, filter: `blur(${(1 - o) * 8}px)`}}>{children}</AbsoluteFill>; };
const Card: React.FC<{children: React.ReactNode; w?: number}> = ({children, w = 800}) => <div style={{width: w, borderRadius: 26, padding: '26px 30px', background: '#fff', color: INK, fontFamily: SANS, boxShadow: '0 26px 54px rgba(60,40,20,0.18)', boxSizing: 'border-box'}}>{children}</div>;
const Stamp: React.FC<{at: number; children: React.ReactNode}> = ({at, children}) => { const s = useSp(at, {damping: 9, stiffness: 220}); if (s <= 0) return null;
  return <div style={{transform: `scale(${2.2 - 1.2 * s}) rotate(-6deg)`, opacity: Math.min(1, s * 3), border: `7px solid ${ROSE}`, color: ROSE, background: '#fff', borderRadius: 18, padding: '4px 28px', fontFamily: DISP, fontSize: 80}}>{children}</div>; };

const Caption: React.FC = () => { const t = useT();
  const pg = data.pages.find((p: any) => t >= p.s - 0.05 && t < (p.hold ?? p.s + 3) - 0.05) as any; if (!pg) return null;
  return <div style={{position: 'absolute', top: 1345, left: 70, right: 70, display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '8px 12px', zIndex: 40}}>
    {pg.words.map((w: any, k: number) => { if (t < w.s - 0.02) return null; const p = L(t, w.s - 0.02, w.s + 0.1, 0, 1, O3);
      return <span key={k} style={{fontFamily: SANS, fontWeight: 900, fontSize: 52, color: w.hl ? '#fff' : INK, background: w.hl ? (w.hl === 'b' ? CER : ROSE) : 'transparent', borderRadius: 12, padding: w.hl ? '0 12px' : 0, transform: `scale(${0.85 + 0.15 * p})`, display: 'inline-block'}}>{w.w}</span>; })}
  </div>; };

export const Scenes: React.FC = () => <>
  <LiveBg />
  <Beat a={0} b={5}>
    <Abs top={360}><Pop at={0.1}><div style={{fontFamily: SANS, fontWeight: 900, fontSize: 88, color: INK, textAlign: 'center', lineHeight: 1.1}}>Tumhari reel<br /><span style={{color: ROSE}}>yahan banegi</span></div></Pop></Abs>
    <Abs top={700}><Pop at={0.8}><Card><div style={{fontSize: 34, fontWeight: 900}}>reel banao: [topic]</div><div style={{fontSize: 24, color: MUTE, marginTop: 8}}>Claude Code ko bolo, ye file wo khud likhega.</div></Card></Pop></Abs>
    <Abs top={1000}><Stamp at={1.8}>READY ✓</Stamp></Abs>
  </Beat>
  <Caption />
</>;
