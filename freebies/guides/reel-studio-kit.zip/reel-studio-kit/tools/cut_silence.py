# Cut pauses from a finished reel (picture + sound together), using the clean VO to find them.
# usage: python3 cut_silence.py vo.wav in.mp4 out.mp4 [min_gap=0.28] [keep=0.09]
import sys, subprocess, numpy as np, soundfile as sf
vo, src, dst = sys.argv[1:4]
min_gap = float(sys.argv[4]) if len(sys.argv) > 4 else 0.28
keep = float(sys.argv[5]) if len(sys.argv) > 5 else 0.09
a, sr = sf.read(vo); a = a if a.ndim == 1 else a.mean(1)
h = int(0.01 * sr)
e = np.array([np.sqrt(np.mean(a[i:i + h] ** 2)) for i in range(0, len(a) - h, h)])
quiet = e < 0.008
dur = float(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', src]).decode())
cuts = []; i = 0
first_voice = int(np.argmax(~quiet))
while i < len(quiet):
    if quiet[i]:
        j = i
        while j < len(quiet) and quiet[j]: j += 1
        s, t = i / 100, j / 100
        if i > first_voice and j < len(quiet) and t - s >= min_gap:  # inner pauses only; keep the outro hold
            cuts.append((s + keep, t - keep))
        i = j
    else: i += 1
keepsegs, last = [], 0.0
for s, t in cuts: keepsegs.append((last, s)); last = t
keepsegs.append((last, dur))
vf = ''.join(f'[0:v]trim={s:.3f}:{t:.3f},setpts=PTS-STARTPTS[v{k}];' for k, (s, t) in enumerate(keepsegs))
af = ''.join(f'[0:a]atrim={s:.3f}:{t:.3f},asetpts=PTS-STARTPTS,afade=t=in:d=0.01,afade=t=out:st={max(0, t - s - 0.012):.3f}:d=0.012[a{k}];' for k, (s, t) in enumerate(keepsegs))
cat = ''.join(f'[v{k}][a{k}]' for k in range(len(keepsegs))) + f'concat=n={len(keepsegs)}:v=1:a=1[v][a]'
subprocess.run(['ffmpeg', '-loglevel', 'error', '-y', '-i', src, '-filter_complex', vf + af + cat, '-map', '[v]', '-map', '[a]',
                '-c:v', 'libx264', '-preset', 'slow', '-crf', '20', '-pix_fmt', 'yuv420p', '-r', '30', '-c:a', 'aac', '-b:a', '256k', '-ar', '48000', '-movflags', '+faststart', dst], check=True)
removed = sum(t - s for s, t in cuts)
print(f'cut {len(cuts)} pauses, removed {removed:.2f}s: {dur:.2f}s -> {dur - removed:.2f}s')
