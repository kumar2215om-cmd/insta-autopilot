// Reel Motion Kit · by @aiwith.om. Video = frames: every component just asks "abhi kaunsa second hai?" (t) and draws itself.
import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig, spring, interpolate} from 'remotion';
import {Brand} from './brand';

export const useT = () => { const f = useCurrentFrame(); const {fps} = useVideoConfig(); return f / fps; };
export const L = (t: number, a: number, b: number, x: number, y: number) => interpolate(t, [a, b], [x, y], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
const useSp = (at: number, cfg = {damping: 14, stiffness: 160}) => { const f = useCurrentFrame(); const {fps} = useVideoConfig(); return f < at * fps ? 0 : spring({frame: f - at * fps, fps, config: cfg}); };

/** Ek section: a se b second tak dikhta hai, end pe blur-fade. */
export const Beat: React.FC<{a: number; b: number; children: React.ReactNode}> = ({a, b, children}) => { const t = useT(); if (t < a || t >= b) return null; const o = L(t, b - 0.15, b, 1, 0);
  return <AbsoluteFill style={{opacity: o, filter: `blur(${(1 - o) * 8}px)`}}>{children}</AbsoluteFill>; };
/** Spring pop-in at `at` seconds (blur se saaf, neeche se upar). */
export const Pop: React.FC<{at: number; y?: number; children: React.ReactNode; style?: React.CSSProperties}> = ({at, y = 22, children, style}) => { const s = useSp(at); if (s <= 0) return null;
  return <div style={{transform: `translateY(${(1 - s) * y}px) scale(${0.8 + 0.2 * s})`, opacity: Math.min(1, s * 2), filter: `blur(${Math.max(0, 1 - s * 1.5) * 8}px)`, ...style}}>{children}</div>; };
/** Bada thappa: 2x se slam karke baithta hai. */
export const Stamp: React.FC<{at: number; b: Brand; color?: string; rot?: number; size?: number; children: React.ReactNode}> = ({at, b, color, rot = -6, size = 80, children}) => { const s = useSp(at, {damping: 9, stiffness: 220}); if (s <= 0) return null; const c = color ?? b.accent;
  return <div style={{display: 'inline-block', transform: `scale(${2.2 - 1.2 * s}) rotate(${rot}deg)`, opacity: Math.min(1, s * 3), border: `7px solid ${c}`, color: c, background: b.card, borderRadius: 18, padding: '4px 28px', fontFamily: b.display, fontSize: size, whiteSpace: 'nowrap'}}>{children}</div>; };
export const Card: React.FC<{b: Brand; w?: number; children: React.ReactNode; style?: React.CSSProperties}> = ({b, w = 820, children, style}) =>
  <div style={{width: w, boxSizing: 'border-box', borderRadius: b.radius, padding: '24px 28px', background: b.card, color: b.ink, fontFamily: b.font, boxShadow: '0 26px 54px rgba(60,40,20,0.16)', ...style}}>{children}</div>;
/** Number ginti karta hua: from → to, a se b second. */
export const CountUp: React.FC<{a: number; b: number; from?: number; to: number; prefix?: string; suffix?: string; style?: React.CSSProperties}> = ({a, b, from = 0, to, prefix = '', suffix = '', style}) => { const t = useT(); const p = L(t, a, b, 0, 1); const v = from + (to - from) * (1 - Math.pow(1 - p, 3));
  return <span style={style}>{prefix}{Math.round(v).toLocaleString('en-IN')}{suffix}</span>; };
/** Typing: text a se b second mein type hota hai, blinking cursor ke saath. */
export const Type: React.FC<{a: number; b: number; text: string; color: string}> = ({a, b, text, color}) => { const t = useT(); const n = Math.round(L(t, a, b, 0, text.length));
  return <span>{text.slice(0, n)}<span style={{opacity: Math.floor(t * 3) % 2 ? 0 : 1, color}}>|</span></span>; };
/** Mouse cursor jo points pe chalta hai aur click karta hai: path = [[sec, x, y], ...]. */
export const Cursor: React.FC<{path: [number, number, number][]; clicks?: number[]; color: string}> = ({path, clicks = [], color}) => { const t = useT(); let x = path[0][1], y = path[0][2];
  for (let i = 1; i < path.length; i++) if (t >= path[i - 1][0]) { const p = L(t, path[i - 1][0], path[i][0], 0, 1); const e = p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2; x = path[i - 1][1] + (path[i][1] - path[i - 1][1]) * e; y = path[i - 1][2] + (path[i][2] - path[i - 1][2]) * e; }
  const down = clicks.some((c) => t >= c && t < c + 0.18);
  return <div style={{position: 'absolute', left: x, top: y, zIndex: 50, transform: `scale(${down ? 0.85 : 1})`}}><svg width={44} height={52} viewBox="0 0 22 26"><path d="M2 2 L2 20 L7 15 L10 23 L13 22 L10 14 L17 14 Z" fill="#1C1A17" stroke="#fff" strokeWidth={1.6} strokeLinejoin="round" /></svg>{down && <div style={{position: 'absolute', left: -14, top: -14, width: 40, height: 40, borderRadius: 20, border: `3px solid ${color}`}} />}</div>; };
/** Camera punch: har beat pe halka zoom-in jhatka (energy badhta hai). */
export const Punch: React.FC<{beats: number[]; children: React.ReactNode}> = ({beats, children}) => { const t = useT(); let k = 0;
  for (const b of beats) if (t >= b && t < b + 0.5) k = Math.max(k, Math.exp(-(t - b) * 9));
  return <AbsoluteFill style={{transform: `scale(${1 + 0.035 * k})`}}>{children}</AbsoluteFill>; };
/** Instagram ka UI yahan aata hai (approx): upar ~220px, neeche ~380px, right ~120px. debug=true karke check karo. */
export const SAFE = {top: 220, bottom: 1920 - 380, right: 1080 - 120, left: 60};
export const SafeZones: React.FC<{show: boolean}> = ({show}) => !show ? null : <AbsoluteFill style={{pointerEvents: 'none', zIndex: 99}}>
  <div style={{position: 'absolute', left: 0, right: 0, top: 0, height: SAFE.top, background: 'rgba(255,0,0,0.25)'}} />
  <div style={{position: 'absolute', left: 0, right: 0, top: SAFE.bottom, bottom: 0, background: 'rgba(255,0,0,0.25)'}} />
  <div style={{position: 'absolute', left: SAFE.right, right: 0, top: SAFE.top, height: SAFE.bottom - SAFE.top, background: 'rgba(255,0,0,0.25)'}} />
  <div style={{position: 'absolute', left: SAFE.left, top: SAFE.top, width: SAFE.right - SAFE.left, height: SAFE.bottom - SAFE.top, border: '4px dashed #16A34A'}} /></AbsoluteFill>;
