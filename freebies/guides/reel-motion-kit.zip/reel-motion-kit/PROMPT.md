Paste in Claude Code inside this folder:

Make this Reel Motion Kit mine.
Brand: background [#…], cards [#…], text [#…], accent [#…], accent2 [#…], font [Google font], corner radius [px], handle [@…].
Scenes I want: [e.g. hook with a big number → 3 tips one by one → comment CTA].
Voice: [public/vo.wav + captions.json from Caption Sync Kit, OR "no voice, time it in seconds"].
1. Read README.md and src/ first. Add my brand as a new preset in src/brand.ts; never hard-code colours in components.
2. Build my scenes as a copy of src/Demo.tsx, using only the blocks in src/motion.tsx. Put every time in the T timeline; with a voice, use the second each word is spoken.
3. Keep all text, numbers and faces inside SAFE (src/motion.tsx).
4. Render stills of each beat with debugSafeZones on and off; look at them yourself and fix overflow, overlap, low contrast, anything in the red zones. Show me the stills.
5. After I say ok, render the MP4.
