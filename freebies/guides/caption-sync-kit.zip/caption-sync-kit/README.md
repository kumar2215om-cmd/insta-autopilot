# Caption Sync Kit · by @aiwith.om

Word-by-word captions jo **tumhari awaaz pe exact** chalte hain. Words tumhare script se, timing awaaz ke pauses se.
**No AI model, no download, no upload, no API key.** Hindi, Hinglish, English: sab same.

## Kaise kaam karta hai
1. Awaaz ki energy se "bolne ke chunks" aur pauses dhundta hai.
2. Tumhari script ki har line ko ek ya zyada chunks se jodta hai (dynamic programming: line ki lambai vs uska audio time, aur break lambe pause pe).
3. Line ke andar har word ko utna time milta hai jitna use bolne mein lagta hai.

Hamare test (3 asli reels, 108 lines): **94% lines 0.15 sec ke andar** sahi start.

## Install
Python 3.9+ aur 2 libraries:
```bash
pip install numpy soundfile
```

## Chalao
```bash
python3 captions_sync.py voice.wav script.txt -o captions.json --spoken spoken.json
```
`voice.wav` (ya mp3 ko `ffmpeg -i voice.mp3 voice.wav` se badlo) · `script.txt` dekho `script_example.txt` · report mein `⚠ check` wali lines ek baar sun lo.

## Remotion mein
`Captions.tsx` ko `src/` mein daalo:
```tsx
import caps from '../public/captions.json';
<Captions data={caps} top={1345} c1="#FF2D95" c2="#007BA7" />
```

## Tips
- Script **wahi** likho jo bola gaya hai. Line break wahan jahan saans/pause hai.
- Numbers/acronyms ke liye `spoken.json` ("$10": "ten dollar") taaki unka time sahi bane.
- Music wali file mat do: sirf voice (music baad mein mix karo).
- Script nahi hai? Pehle kisi bhi Whisper tool se text nikaalo, phir yahan lines banao.

MIT licence · Remotion ka apna licence hai (badi company ho to remotion.dev/license).
