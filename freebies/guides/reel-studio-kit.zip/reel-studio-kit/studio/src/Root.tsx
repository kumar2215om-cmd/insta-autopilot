import React from 'react';
import {Composition} from 'remotion';
import {Reel} from './Reel';
import data from './data.json';

export const Root: React.FC = () => (<>
  <Composition id="Reel" component={Reel} fps={30} width={1080} height={1920} durationInFrames={Math.ceil(data.dur * 30) + 50} />
</>);
