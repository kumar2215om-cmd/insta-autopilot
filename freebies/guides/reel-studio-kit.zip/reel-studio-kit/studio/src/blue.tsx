// Shared "aiwith.om" blue style: black dot grid, glass cards, 3D blue-gradient headlines,
// numbered step pill, big 1–3-word captions that blur in.
import React, {CSSProperties} from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';

export const BLUE = {
  bg: '#0A0A0A', deep: '#003A52', b1: '#007BA7', b2: '#1FB0E6', b3: '#8BE0FF', glowRGB: '0,150,210', rose: '#FF2D95', roseRGB: '255,45,149',
  text: '#F3F5F9', sub: '#9AA3B2', faint: '#4B5262', glass: 'rgba(255,255,255,0.045)', glass2: 'rgba(255,255,255,0.075)', edge: 'rgba(255,255,255,0.10)',
  green: '#22C55E', red: '#F43F5E', amber: '#F5B83D',
};
export const GRAD = `linear-gradient(100deg, ${BLUE.b1} 0%, ${BLUE.b2} 40%, ${BLUE.rose} 100%)`;
export const CGRAD = `linear-gradient(100deg, ${BLUE.b2} 0%, ${BLUE.b3} 100%)`;
export const DISPLAY = "'Inter', 'Noto Sans Devanagari', 'Noto Color Emoji', sans-serif";
const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

export const BlueBg: React.FC = () => (
  <AbsoluteFill style={{background: BLUE.bg}}>
    <AbsoluteFill style={{backgroundImage: 'radial-gradient(rgba(255,255,255,0.06) 1.6px, transparent 2px)', backgroundSize: '38px 38px', backgroundPosition: '19px 19px'}} />
    <AbsoluteFill style={{background: 'radial-gradient(ellipse 70% 55% at 50% 38%, transparent 30%, rgba(0,0,0,0.75) 100%)'}} />
    <AbsoluteFill style={{background: `radial-gradient(circle at 50% 30%, rgba(${BLUE.glowRGB},0.10), transparent 45%)`}} />
  </AbsoluteFill>
);

// 3D extruded gradient text
export const extrude = (depth = 9) => Array.from({length: depth}).map((_, i) => `0 ${i + 1}px 0 ${i < depth - 2 ? '#5A0F3A' : '#21061A'}`).join(', ') + `, 0 ${depth + 6}px 22px rgba(0,0,0,0.55)`;
// stacked: solid extruded base + gradient face on top (shadows on clipped text would cover the gradient)
const Layered: React.FC<{children: React.ReactNode; shadow: string}> = ({children, shadow}) => (
  <span style={{position: 'relative', display: 'inline-block'}}>
    <span style={{color: '#003A52', textShadow: shadow}}>{children}</span>
    <span style={{position: 'absolute', left: 0, top: 0, right: 0, background: GRAD, WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent', textShadow: 'none'}}>{children}</span>
  </span>
);
export const Hero: React.FC<{children: React.ReactNode; size?: number; style?: CSSProperties; depth?: number}> = ({children, size = 200, style, depth}) => (
  <div style={{fontFamily: DISPLAY, fontWeight: 900, fontSize: size, lineHeight: 1.05, letterSpacing: -size * 0.045, textAlign: 'center', whiteSpace: 'nowrap', ...style}}>
    <Layered shadow={extrude(depth ?? Math.max(5, Math.round(size / 22))) + `, 0 0 ${size * 0.3}px rgba(${BLUE.glowRGB},0.55)`}>{children}</Layered>
  </div>
);
export const GradText: React.FC<{children: React.ReactNode; glow?: boolean}> = ({children, glow = true}) => (
  <Layered shadow={glow ? `0 0 26px rgba(${BLUE.glowRGB},0.75), 0 0 8px rgba(${BLUE.glowRGB},0.5)` : 'none'}>{children}</Layered>
);

export const glass = (extra?: CSSProperties): CSSProperties => ({
  background: `linear-gradient(180deg, rgba(255,255,255,0.065), rgba(255,255,255,0.03))`, border: `1.5px solid ${BLUE.edge}`, borderRadius: 30,
  boxShadow: '0 30px 80px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.06)', ...extra,
});

// "01 STEP NAME ☐" pill; ticks when the chapter ends
export const StepPill: React.FC<{chapters: [number, string, string?][]; total: number; top?: number}> = ({chapters, total, top = 120}) => {
  const f = useCurrentFrame(); const t = f / 30;
  const idx = chapters.filter(([s]) => t >= s).length - 1;
  if (idx < 0) return null;
  const [start, label, badge] = chapters[idx];
  const num = badge ?? String(idx + 1).padStart(2, '0');
  const end = idx + 1 < chapters.length ? chapters[idx + 1][0] : total;
  const p = interpolate(f, [start * 30, start * 30 + 8], [0, 1], clamp);
  const done = t >= end - 0.5;
  const tick = interpolate(f, [(end - 0.5) * 30, (end - 0.5) * 30 + 6], [0, 1], clamp);
  return (
    <div style={{position: 'absolute', top, left: 0, right: 0, display: 'flex', justifyContent: 'center', opacity: p, transform: `translateY(${(1 - p) * -16}px) scale(${0.9 + 0.1 * p})`}}>
      <div style={{display: 'flex', alignItems: 'center', gap: 16, padding: '10px 14px 10px 10px', borderRadius: 50, background: 'rgba(255,255,255,0.06)', border: `1.5px solid ${BLUE.edge}`}}>
        <div style={{width: 56, height: 56, borderRadius: 28, background: GRAD, color: '#fff', fontFamily: DISPLAY, fontWeight: 900, fontSize: num.length > 2 ? 19 : 24, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{num}</div>
        <div style={{fontFamily: DISPLAY, fontWeight: 800, fontSize: 28, letterSpacing: 4, color: BLUE.text}}>{label}</div>
        <div style={{width: 44, height: 44, borderRadius: 12, border: `2.5px solid ${done ? BLUE.green : 'rgba(255,255,255,0.3)'}`, background: done ? 'rgba(34,197,94,0.15)' : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
          {done && <svg width="26" height="26" viewBox="0 0 30 30"><path d="M5 16 L12 23 L25 8" fill="none" stroke={BLUE.green} strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="34" strokeDashoffset={34 * (1 - tick)} /></svg>}
        </div>
      </div>
    </div>
  );
};

// Big captions: 1–3 words at a time, each word blurs/stretches in when spoken; keywords in blue gradient.
type W = {w: string; s: number; e: number; hl?: string};
export const chunkWords = (pages: {words: W[]}[], maxWords = 3, maxChars = 16) => {
  const out: {words: W[]; s: number; hold: number}[] = [];
  for (const pg of pages) {
    let cur: W[] = [];
    const flush = () => { if (cur.length) out.push({words: cur, s: cur[0].s, hold: 0}); cur = []; };
    for (const w of pg.words) {
      const len = [...cur, w].map((x) => x.w).join(' ').length;
      if (cur.length && (cur.length >= maxWords || len > maxChars)) flush();
      cur.push(w);
      if (/[.?!।,…]$/.test(w.w) && cur.length >= 2) flush();
    }
    flush();
  }
  out.forEach((c, i) => {
    const last = c.words[c.words.length - 1].e;
    c.hold = i + 1 < out.length ? Math.min(out[i + 1].s, last + 0.7) : last + 1.2;
  });
  return out;
};
export const BigCaptions: React.FC<{chunks: {words: W[]; s: number; hold: number}[]; top?: number; size?: number}> = ({chunks, top = 1230, size = 104}) => {
  const f = useCurrentFrame(); const t = f / 30;
  const c = chunks.find((k) => t >= k.s - 0.03 && t < k.hold);
  if (!c) return null;
  const len = c.words.map((w) => w.w).join(' ').length;
  size = len > 15 ? Math.round(size * Math.max(0.62, 15 / len)) : size;
  return (
    <div style={{position: 'absolute', left: 50, right: 50, top, display: 'flex', flexWrap: 'wrap', justifyContent: 'center', alignItems: 'baseline', columnGap: '0.22em',
      fontFamily: DISPLAY, fontWeight: 900, fontSize: size, lineHeight: 1.12, letterSpacing: -size * 0.04, color: BLUE.text, textShadow: '0 6px 30px rgba(0,0,0,0.8)'}}>
      {c.words.map((w, i) => {
        if (t < w.s - 0.02) return null;
        const p = interpolate(f, [w.s * 30 - 1, w.s * 30 + 4], [0, 1], clamp);
        const style: CSSProperties = {display: 'inline-block', opacity: p, transform: `scaleX(${1 + (1 - p) * 0.25}) translateY(${(1 - p) * 10}px)`, filter: p < 1 ? `blur(${(1 - p) * 14}px)` : undefined};
        return <span key={i} style={{...style, ...(w.hl === 'o' ? {color: BLUE.rose, textShadow: `0 0 26px rgba(${BLUE.roseRGB},0.75)`} : w.hl ? {color: BLUE.b3, textShadow: `0 0 26px rgba(${BLUE.glowRGB},0.8)`} : {})}}>{w.w}</span>;
      })}
    </div>
  );
};

// floating 3D-ish emoji sticker
export const Sticker: React.FC<{e: string; x: number; y: number; size?: number; at?: number; rot?: number}> = ({e, x, y, size = 110, at = 0, rot = -10}) => {
  const f = useCurrentFrame();
  if (f < at * 30) return null;
  const p = interpolate(f, [at * 30, at * 30 + 8], [0, 1], clamp);
  return <div style={{position: 'absolute', left: x, top: y + Math.sin(f / 10) * 6, fontSize: size, transform: `scale(${0.4 + 0.6 * p}) rotate(${rot + Math.sin(f / 14) * 4}deg)`, opacity: p, filter: 'drop-shadow(0 14px 22px rgba(0,0,0,0.6))'}}>{e}</div>;
};

export const FollowCTA: React.FC<{at: number; top: number; comment?: string}> = ({at, top, comment}) => {
  const f = useCurrentFrame(); const t = f / 30;
  if (t < at) return null;
  const p = interpolate(f, [at * 30, at * 30 + 10], [0, 1], clamp);
  return (
    <div style={{position: 'absolute', left: 0, right: 0, top, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 34, opacity: p, transform: `translateY(${(1 - p) * 30}px)`}}>
      {comment && (
        <div style={{...glass({width: 820, padding: '22px 26px', borderRadius: 34}), position: 'relative'}}>
          <div style={{fontFamily: DISPLAY, fontWeight: 800, fontSize: 24, letterSpacing: 4, color: BLUE.sub, marginBottom: 14}}>💬 COMMENT KARO</div>
          <div style={{display: 'flex', alignItems: 'center', gap: 16, borderRadius: 40, border: `2px solid rgba(${BLUE.glowRGB},0.6)`, padding: '14px 14px 14px 22px'}}>
            <div style={{width: 34, height: 34, borderRadius: 17, background: GRAD}} />
            <div style={{flex: 1, fontFamily: DISPLAY, fontWeight: 900, fontSize: 52, color: BLUE.text}}>{comment.slice(0, Math.max(0, Math.floor((t - at - 0.3) * 14)))}</div>
            <div style={{width: 66, height: 66, borderRadius: 33, background: GRAD, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
              <svg width="30" height="30" viewBox="0 0 24 24"><path d="M3 11 L21 3 L13 21 L11 13 Z" fill="none" stroke="#fff" strokeWidth="2.4" strokeLinejoin="round" /></svg>
            </div>
          </div>
          <div style={{position: 'absolute', right: -24, top: -40, fontSize: 84, transform: `rotate(12deg) scale(${1 + 0.06 * Math.sin(f / 6)})`}}>🩷</div>
        </div>
      )}
      <div style={{display: 'flex', alignItems: 'center', gap: 22}}>
        <div style={{background: '#fff', color: '#0A0A0A', borderRadius: 50, padding: '18px 44px', fontFamily: DISPLAY, fontWeight: 900, fontSize: 46, boxShadow: `0 0 40px rgba(${BLUE.glowRGB},0.5)`}}>+ Follow</div>
        <div style={{fontSize: 70, transform: `rotate(${Math.sin(f / 3) * 12}deg)`}}>🔔</div>
      </div>
      <div style={{fontFamily: DISPLAY, fontWeight: 800, fontSize: 36, color: BLUE.sub}}>@aiwith.om</div>
    </div>
  );
};
