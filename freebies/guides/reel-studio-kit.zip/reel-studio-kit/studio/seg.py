import numpy as np, soundfile as sf, json
x,sr=sf.read('vo.wav'); w=int(0.01*sr); n=len(x)//w
r=np.sqrt((x[:n*w].reshape(n,w)**2).mean(1)); on=r>0.008; segs=[]; s=None
for i,v in enumerate(on):
    if v and s is None: s=i
    if not v and s is not None: segs.append([s,i]); s=None
if s is not None: segs.append([s,n])
m=[]
for a,b in segs:
    if m and a-m[-1][1]<16: m[-1][1]=b
    else: m.append([a,b])
m=[[a/100,b/100] for a,b in m if b-a>=8]
sp=sum(b-a for a,b in m); print('raw',round(len(x)/sr,2),'n',len(m),'speech',round(sp,2),'est',round(sp+0.14*len(m)+1.9,2))
json.dump(m,open('segs.json','w'))
