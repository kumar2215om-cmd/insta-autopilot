import {bundle} from '@remotion/bundler';
import {selectComposition, renderStill, openBrowser} from '@remotion/renderer';
import {execSync} from 'child_process';
import path from 'path';
const frames = process.argv[2].split(',').map(Number);
const out = process.argv[3] || 'out/sheet.png';
const serveUrl = await bundle({entryPoint: path.resolve('src/index.ts')});
const browserExecutable = process.env.BROWSER_EXECUTABLE || null;
const puppeteerInstance = await openBrowser('chrome', {browserExecutable});
const composition = await selectComposition({serveUrl, id: process.env.COMP || 'Reel', puppeteerInstance});
const files = [];
for (const f of frames) {
  const o = `out/stills/s${f}.png`;
  await renderStill({serveUrl, composition, frame: f, output: o, scale: 0.25, puppeteerInstance, overwrite: true});
  files.push(o);
}
await puppeteerInstance.close({silent: true});
const cols = Number(process.env.COLS || 6);
const rows = [];
for (let i = 0; i < files.length; i += cols) rows.push(files.slice(i, i + cols));
const parts = rows.map((r, k) => {
  while (r.length < cols) r.push(r[r.length - 1]);
  const o = `out/stills/row${k}.png`;
  execSync(`ffmpeg -loglevel error -y ${r.map((x) => `-i ${x}`).join(' ')} -filter_complex "${r.map((_, i) => `[${i}]drawtext=text='${frames[k * cols + i] ?? ''}':x=8:y=8:fontsize=22:fontcolor=lime:box=1:boxcolor=black[v${i}]`).join(';')};${r.map((_, i) => `[v${i}]`).join('')}hstack=${cols}" ${o}`);
  return o;
});
execSync(`ffmpeg -loglevel error -y ${parts.map((x) => `-i ${x}`).join(' ')} -filter_complex "${parts.length > 1 ? parts.map((_, i) => `[${i}]`).join('') + `vstack=${parts.length}` : '[0]copy'}" ${out}`);
console.log('done', out);
