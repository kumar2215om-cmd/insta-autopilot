// Demo: "3 tips" reel (6 sec, no voice). Copy this file for every new scene.
import React from 'react';
import {AbsoluteFill} from 'remotion';
import '@fontsource/inter/800.css';
import '@fontsource/inter/900.css';
import '@fontsource/anton/400.css';
import {useBrand} from './brand';
import {Beat, Pop, Stamp, Card, CountUp, Type, Cursor, Punch, SafeZones} from './motion';

// ⏱️ Timeline: voice ho to yahan wahi seconds daalo jab wo word bola gaya (captions kit se milte hain)
const T = {title: 0.1, number: 0.6, tip1: 1.4, tip2: 2.0, tip3: 2.6, stamp: 3.2, cta: 4.2};
const Abs: React.FC<{top: number; children: React.ReactNode}> = ({top, children}) => <div style={{position: 'absolute', top, left: 0, right: 0, display: 'flex', justifyContent: 'center'}}>{children}</div>;

export const Demo: React.FC<{preset?: string; debugSafeZones?: boolean}> = ({preset, debugSafeZones = false}) => {
  const b = useBrand(preset);
  return <AbsoluteFill style={{background: b.bg, fontFamily: b.font, color: b.ink}}>
    <Punch beats={[T.title, T.number, T.stamp, T.cta]}>
      <Beat a={0} b={4.1}>
        <Abs top={250}><Pop at={T.title}><div style={{fontWeight: 900, fontSize: 82, textAlign: 'center', lineHeight: 1.08}}>Better reels ke<br /><span style={{color: b.accent}}>tips</span></div></Pop></Abs>
        <Abs top={500}><Pop at={T.number}><Card b={b}><div style={{display: 'flex', alignItems: 'center', gap: 24}}><CountUp a={T.number} b={T.number + 0.7} to={3} style={{fontFamily: b.display, fontSize: 150, color: b.accent2, lineHeight: 1}} /><div style={{fontWeight: 900, fontSize: 40}}>tips jo sach mein<br />kaam karte hain</div></div>
          {[[T.tip1, 'Hook 2 second mein'], [T.tip2, 'Text safe zone mein'], [T.tip3, 'Har beat pe kuch naya']].map(([a, s], i) => <Pop key={i} at={a as number}><div style={{marginTop: 14, background: b.bg, borderRadius: b.radius / 2, padding: '12px 18px', fontWeight: 800, fontSize: 32}}><span style={{color: b.ok}}>✓</span> {s as string}</div></Pop>)}</Card></Pop></Abs>
        <Abs top={1180}><Stamp at={T.stamp} b={b}>SAVE KARO</Stamp></Abs>
      </Beat>
      <Beat a={4.1} b={99}>
        <Abs top={420}><Pop at={T.cta}><Card b={b}><div style={{fontWeight: 800, fontSize: 22, color: b.mute, letterSpacing: 2}}>COMMENT</div>
          <div style={{marginTop: 10, border: `3px solid ${b.accent}`, borderRadius: 40, padding: '10px 22px', fontWeight: 900, fontSize: 56}}><Type a={T.cta + 0.3} b={T.cta + 0.9} text="TIPS" color={b.accent} /></div></Card></Pop></Abs>
        <Cursor path={[[T.cta, 900, 1100], [T.cta + 1.0, 780, 610], [6, 780, 610]]} clicks={[T.cta + 1.1]} color={b.accent} />
        <Abs top={1180}><Pop at={T.cta + 1.2}><div style={{fontWeight: 900, fontSize: 40, color: b.mute}}>{b.handle}</div></Pop></Abs>
      </Beat>
    </Punch>
    <SafeZones show={debugSafeZones} />
  </AbsoluteFill>;
};
