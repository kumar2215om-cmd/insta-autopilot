#!/usr/bin/env python3
"""Caption Sync (aiwith.om) — word-timed captions from YOUR script + the voice's pauses. No AI model, no upload.

usage:  python3 captions_sync.py voice.wav script.txt  [-o captions.json] [--gap 0.16] [--spoken spoken.json]

script.txt = one caption line per spoken phrase (break lines where the voice pauses).
  *word = highlight colour 1, ^word = highlight colour 2, words_joined_by_underscore = one caption word.
How it works: find speech chunks from audio energy → make the number of chunks equal the number of lines
(best grouping by dynamic programming: each line's audio length vs. the time its text needs, breaks on long pauses) → spread each
line's words over its chunk by how long each word takes to say.
"""
import argparse, json, re, sys
import numpy as np, soundfile as sf

def load(p):
    x, sr = sf.read(p, always_2d=True); return x.mean(1), sr

def chunks(x, sr, gap, thr=None):
    w = int(0.01 * sr); n = len(x) // w
    r = np.sqrt((x[:n * w].reshape(n, w) ** 2).mean(1))
    if thr is None: thr = max(0.004, np.percentile(r, 95) * 0.06)  # adapts to quiet/loud recordings
    on = r > thr; segs = []; s = None
    for i, v in enumerate(on):
        if v and s is None: s = i
        if not v and s is not None: segs.append([s, i]); s = None
    if s is not None: segs.append([s, n])
    m = []
    for a, b in segs:
        if m and a - m[-1][1] < gap * 100: m[-1][1] = b
        else: m.append([a, b])
    m = [[a, b] for a, b in m if b - a >= 8]
    return m, r

def fit(m, r, k, lw):
    """Group the n speech chunks into k lines (contiguous). Dynamic programming: each line's audio length should
    match the time its text needs (lw = text weight per line), and line breaks should sit on longer pauses."""
    n = len(m)
    if n < k:  # more lines than chunks: split the longest chunk at its quietest point until n == k
        m = [list(s) for s in m]
        while len(m) < k:
            i = max(range(len(m)), key=lambda j: m[j][1] - m[j][0]); a, b = m[i]
            lo, hi = a + (b - a) // 5, b - (b - a) // 5
            if hi - lo < 4: break
            c = lo + int(np.argmin(r[lo:hi])); m[i:i + 1] = [[a, c], [c, b]]
        return m
    speech = sum(b - a for a, b in m); rate = speech / sum(lw)
    gaps = [m[i + 1][0] - m[i][1] for i in range(n - 1)]
    INF = float('inf'); D = [[INF] * (n + 1) for _ in range(k + 1)]; B = [[0] * (n + 1) for _ in range(k + 1)]; D[0][0] = 0
    for j in range(1, k + 1):
        for i in range(j, n - (k - j) + 1):
            for t in range(j - 1, i):
                if D[j - 1][t] == INF: continue
                dur = m[i - 1][1] - m[t][0]; exp = lw[j - 1] * rate
                c = np.log(max(dur, 1) / max(exp, 1)) ** 2
                if i < n: c -= 0.35 * np.log(1 + gaps[i - 1] / 10)  # reward ending this line on a long pause
                if D[j - 1][t] + c < D[j][i]: D[j][i] = D[j - 1][t] + c; B[j][i] = t
    out = []; i = n
    for j in range(k, 0, -1):
        t = B[j][i]; out.append([m[t][0], m[i - 1][1]]); i = t
    return out[::-1]

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('voice'); ap.add_argument('script')
    ap.add_argument('-o', '--out', default='captions.json'); ap.add_argument('--gap', type=float, default=0.16)
    ap.add_argument('--spoken', help='json {"$10": "ten dollar"} so numbers/acronyms get the right length')
    a = ap.parse_args()
    lines = [l.strip() for l in open(a.script, encoding='utf-8') if l.strip() and not l.startswith('#')]
    spoken = json.load(open(a.spoken, encoding='utf-8')) if a.spoken else {}
    x, sr = load(a.voice); m, r = chunks(x, sr, a.gap)
    if not m: sys.exit('No speech found. Is the file silent?')
    def weight(t):
        core = re.sub(r'[?।.,…"!:;]', '', t).lstrip('^*'); sp = spoken.get(core, core)
        return len(sp.replace('_', ' ')) + 2.5
    raw = len(m); m = fit(m, r, len(lines), [sum(weight(t) for t in l.split()) for l in lines])
    if len(m) != len(lines): sys.exit(f'Could not match {len(lines)} lines to the audio. Check script.txt.')
    pages = []; report = []
    for li, (line, (s0, e0)) in enumerate(zip(lines, m)):
        s, e = s0 / 100, e0 / 100; toks = line.split(); ws = np.array([weight(t) for t in toks])
        edges = s + (e - s) * np.concatenate([[0], np.cumsum(ws) / ws.sum()])
        words = [dict(w=t.lstrip('^*').replace('_', ' '), s=round(float(edges[i]), 3), e=round(float(edges[i + 1]), 3),
                      hl='b' if t.startswith('^') else 'o' if t.startswith('*') else '') for i, t in enumerate(toks)]
        pages.append(dict(words=words, s=words[0]['s'])); cps = sum(len(t) for t in toks) / max(0.1, e - s)
        flag = '  ⚠ check: too fast' if cps > 24 else '  ⚠ check: too slow' if cps < 4 else ''
        report.append(f'{s:6.2f}–{e:6.2f}  {line[:60]}{flag}')
    for i, p in enumerate(pages):
        nxt = pages[i + 1]['s'] if i + 1 < len(pages) else p['words'][-1]['e'] + 1.5
        p['hold'] = round(min(nxt, p['words'][-1]['e'] + 0.9), 3)
    json.dump(dict(pages=pages, dur=len(x) / sr), open(a.out, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f'speech chunks found: {raw} → matched to {len(lines)} lines\n' + '\n'.join(report) + f'\n✓ wrote {a.out}')

if __name__ == '__main__': main()
