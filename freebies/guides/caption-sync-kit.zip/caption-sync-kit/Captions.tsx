// Word-by-word captions for Remotion, reading captions.json from captions_sync.py.
// usage:  import caps from '../public/captions.json';   <Captions data={caps} top={1345} />
import React from 'react';
import {useCurrentFrame, useVideoConfig, interpolate} from 'remotion';

type W = {w: string; s: number; e: number; hl: string};
type Page = {words: W[]; s: number; hold: number};
export const Captions: React.FC<{data: {pages: Page[]}; top?: number; size?: number; ink?: string; c1?: string; c2?: string; font?: string}> =
  ({data, top = 1345, size = 52, ink = '#1C1A17', c1 = '#FF2D95', c2 = '#007BA7', font = "Inter, 'Noto Sans Devanagari', sans-serif"}) => {
  const t = useCurrentFrame() / useVideoConfig().fps;
  const pg = data.pages.find((p) => t >= p.s - 0.05 && t < p.hold - 0.05);
  if (!pg) return null;
  return <div style={{position: 'absolute', top, left: 70, right: 70, display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '8px 12px'}}>
    {pg.words.map((w, k) => {
      if (t < w.s - 0.02) return null;                      // word appears exactly when it is spoken
      const p = interpolate(t, [w.s - 0.02, w.s + 0.1], [0, 1], {extrapolateRight: 'clamp'});
      return <span key={k} style={{fontFamily: font, fontWeight: 900, fontSize: size, color: w.hl ? '#fff' : ink,
        background: w.hl ? (w.hl === 'b' ? c2 : c1) : 'transparent', borderRadius: 12, padding: w.hl ? '0 12px' : 0,
        transform: `scale(${0.85 + 0.15 * p})`, display: 'inline-block'}}>{w.w}</span>;
    })}
  </div>;
};
