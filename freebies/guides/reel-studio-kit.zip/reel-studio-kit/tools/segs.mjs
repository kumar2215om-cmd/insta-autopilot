// usage: node segs.mjs <wav 16k mono> <segs.json [[s,e],...]> [language] -> one line per segment
import { pipeline, env } from '@huggingface/transformers';
import fs from 'fs';
env.localModelPath = new URL('./node_modules/sts-whisper-small/models/', import.meta.url).pathname;
env.allowRemoteModels = false;
const [wav, segf, lang = 'hindi'] = process.argv.slice(2);
const buf = fs.readFileSync(wav);
let off = 12, data;
while (off < buf.length) { const id = buf.toString('ascii', off, off + 4), sz = buf.readUInt32LE(off + 4);
  if (id === 'data') { data = buf.subarray(off + 8, off + 8 + sz); break; } off += 8 + sz; }
const audio = new Float32Array(data.length / 2); for (let i = 0; i < audio.length; i++) audio[i] = data.readInt16LE(i * 2) / 32768;
const asr = await pipeline('automatic-speech-recognition', 'Xenova/whisper-small', { dtype: 'q8' });
for (const [s, e] of JSON.parse(fs.readFileSync(segf))) {
  const a = audio.slice(Math.max(0, Math.floor((s - 0.05) * 16000)), Math.floor((e + 0.05) * 16000));
  const out = await asr(a, { language: lang, task: 'transcribe' });
  console.log(`${s.toFixed(2)} ${e.toFixed(2)} ${out.text.trim()}`);
}
