#!/usr/bin/env bash
# One command: render -> loudness -14 LUFS -> cut silences -> 1.1x speed -> contact sheet for self-check.
# usage: bash render.sh  [speed]      (run from the kit folder; speed default 1.1)
set -e
SPEED=${1:-1.1}
cd "$(dirname "$0")/studio"
mkdir -p out ../deliver
python3 build_audio.py
npx remotion render src/index.ts Reel out/raw.mp4 --codec=h264 --crf=16 --audio-codec=aac --audio-bitrate=320k
ffmpeg -v error -y -i out/raw.mp4 -c:v copy -af loudnorm=I=-14:TP=-1.5:LRA=11 -ar 48000 -c:a aac -b:a 320k out/norm.mp4
python3 ../tools/cut_silence.py vo.wav out/norm.mp4 out/cut.mp4 0.22 0.07
ffmpeg -v error -y -i out/cut.mp4 -filter_complex "[0:v]setpts=PTS/$SPEED[v];[0:a]atempo=$SPEED,loudnorm=I=-14:TP=-1.5:LRA=11[a]" -map "[v]" -map "[a]" -c:v libx264 -crf 16 -pix_fmt yuv420p -c:a aac -b:a 320k ../deliver/Reel.mp4
D=$(ffprobe -v error -show_entries format=duration -of csv=p=0 ../deliver/Reel.mp4)
ffmpeg -v error -y -i ../deliver/Reel.mp4 -vf "fps=12/$D,scale=180:-1,tile=6x2" -frames:v 1 ../deliver/contact_sheet.png
echo "DONE  deliver/Reel.mp4  (${D}s)  ·  check deliver/contact_sheet.png before posting"
