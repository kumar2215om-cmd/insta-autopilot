#!/usr/bin/env bash
# Checks everything the kit needs and installs the JS parts.
cd "$(dirname "$0")"
ok(){ printf "  ✓ %s\n" "$1"; }; bad(){ printf "  ✗ %s  ->  %s\n" "$1" "$2"; MISSING=1; }
echo "Reel Studio Kit · setup check"
command -v node >/dev/null && ok "Node $(node -v)" || bad "Node.js 18+" "https://nodejs.org"
command -v ffmpeg >/dev/null && ok "ffmpeg" || bad "ffmpeg" "Mac: brew install ffmpeg · Windows: winget install ffmpeg"
command -v python3 >/dev/null && ok "Python $(python3 -V | cut -d' ' -f2)" || bad "Python 3.9+" "https://python.org"
python3 -c "import numpy, scipy, soundfile" 2>/dev/null && ok "numpy / scipy / soundfile" || { echo "  … installing Python libs"; python3 -m pip install -q numpy scipy soundfile && ok "Python libs installed"; }
[ -d studio/node_modules ] || { echo "  … npm install (studio, first time ~2 min)"; (cd studio && npm install --no-audit --no-fund >/dev/null) && ok "Remotion installed"; }
[ -d tools/node_modules ] || { echo "  … installing offline Whisper (captions)"; (cd tools && cp asr_package.json package.json && npm i --ignore-scripts --no-audit --no-fund >/dev/null) && ok "Whisper installed"; }
[ -z "$MISSING" ] && echo "All set ✓  Ab Claude Code mein bolo:  reel banao: [topic]" || echo "Upar wale ✗ install karo, phir dobara chalao."
