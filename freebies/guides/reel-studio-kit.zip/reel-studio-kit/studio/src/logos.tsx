// Official platform logos (Simple Icons, CC0 paths) as app-style tiles.
// LinkedIn / Windows are drawn from their simple official shapes (not in Simple Icons).
import React from 'react';
import P from './logo_paths.json';

type Name = keyof typeof P | 'linkedin' | 'windows';
const BG: Record<string, string> = {mistralai: '#FFFFFF', perplexity: '#1F1F1F', googleslides: '#FFFFFF', stripe: '#635BFF', googlegemini: '#FFFFFF', googlecalendar: '#FFFFFF', bytedance: '#FFFFFF', coolify: '#6B16ED', supabase: '#1C1C1C', ollama: '#FFFFFF', langflow: '#FFFFFF', dify: '#FFFFFF', vercel: '#000000', netlify: '#FFFFFF', firebase: '#FFFFFF', postgresql: '#FFFFFF', docker: '#FFFFFF', googlesheets: '#FFFFFF', javascript: '#F7DF1E', digitalocean: '#FFFFFF', deepseek: '#FFFFFF', googlechrome: '#FFFFFF', react: '#20232A', vuedotjs: '#FFFFFF', webgpu: '#FFFFFF', html5: '#E34F26', espressif: '#FFFFFF', pihole: '#FFFFFF', platformio: '#FFFFFF', 
  youtube: '#FF0000', instagram: 'radial-gradient(circle at 30% 107%, #fdf497 0%, #fdf497 5%, #fd5949 45%, #d6249f 60%, #285AEB 90%)', tiktok: '#000000', x: '#000000',
  googlemaps: '#FFFFFF', whatsapp: '#25D366', gmail: '#FFFFFF', claude: '#D97757', anthropic: '#191919', upwork: '#14A800', github: '#181717', apple: '#000000',
  linux: '#FCC624', soundcloud: '#FF5500', twitch: '#9146FF', reddit: '#FF4500', vimeo: '#1AB7EA', pinterest: '#E60023', bilibili: '#00A1D6', dailymotion: '#0D0D0D',
  udemy: '#A435F0', facebook: '#0866FF', meta: '#FFFFFF', google: '#FFFFFF', linkedin: '#0A66C2', windows: '#FFFFFF', steam: '#171A21', googledrive: '#FFFFFF', qbittorrent: '#2F67BA',
};
const FG: Record<string, string> = {mistralai: '#FA520F', perplexity: '#20B8CD', googleslides: '#F4B400', googlegemini: '#8E75B2', bytedance: '#3C8CFF', supabase: '#3FCF8E', ollama: '#000000', langflow: '#000000', dify: '#0033FF', netlify: '#00C7B7', firebase: '#DD2C00', postgresql: '#4169E1', docker: '#2496ED', googlesheets: '#34A853', javascript: '#000000', digitalocean: '#0080FF', deepseek: '#4D6BFE', googlechrome: '#4285F4', react: '#61DAFB', vuedotjs: '#4FC08D', webgpu: '#005A9C', espressif: '#E7352C', pihole: '#96060C', platformio: '#F5822A', googlecalendar: '#4285F4', googledrive: '#1FA463', googlemaps: '#4285F4', gmail: '#EA4335', meta: '#0081FB', google: '#4285F4', linux: '#000000', windows: '#0078D4'};

export const Logo: React.FC<{name: Name; s?: number; tile?: boolean}> = ({name, s = 120, tile = true}) => {
  const fg = FG[name] ?? '#FFFFFF';
  const g = tile ? s * 0.58 : s;
  let glyph: React.ReactNode;
  if (name === 'linkedin') glyph = <div style={{fontFamily: 'Inter, Arial, sans-serif', fontWeight: 900, fontSize: g * 0.82, color: '#fff', letterSpacing: -g * 0.04, lineHeight: 1, marginTop: -g * 0.06}}>in</div>;
  else if (name === 'windows') glyph = <svg width={g} height={g} viewBox="0 0 24 24"><path d="M2 2h9.5v9.5H2zM12.5 2H22v9.5h-9.5zM2 12.5h9.5V22H2zM12.5 12.5H22V22h-9.5z" fill={fg} /></svg>;
  else glyph = <svg width={g} height={g} viewBox="0 0 24 24"><path d={(P as Record<string, string>)[name]} fill={tile ? fg : (BG[name].startsWith('#') && BG[name] !== '#FFFFFF' ? BG[name] : fg)} /></svg>;
  if (!tile) return <>{glyph}</>;
  return (
    <div style={{width: s, height: s, borderRadius: s * 0.24, background: BG[name], display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 10px 26px rgba(0,0,0,0.45), inset 0 1px 0 rgba(255,255,255,0.2)', flexShrink: 0}}>{glyph}</div>
  );
};
