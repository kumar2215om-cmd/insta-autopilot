// aiwith.om motion kit (from OmniGet v2, the approved standard):
// spring pop-ins (Sp), camera punch-ins on beats (Stage + BEATS), zoom-through segments (Seg),
// highlight rings, spark bursts, moving glow blobs. Pair with blue.tsx.
import React from 'react';
import {AbsoluteFill, interpolate, random, spring, useCurrentFrame} from 'remotion';
import {K, SANS, FPS, cl, useT} from './kit';
import {BLUE, glass} from './blue';
// ---------- motion helpers ----------
export const L = (t: number, a: number, b: number, x: number, y: number, e?: (v: number) => number) => interpolate(t, [a, b], [x, y], {...cl, easing: e});
export const O3 = (x: number) => 1 - Math.pow(1 - x, 3);
export const IO = (x: number) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);
export const useSp = (at: number, cfg = {damping: 13, stiffness: 170}) => { const f = useCurrentFrame(); return f < at * FPS ? 0 : spring({frame: f - at * FPS, fps: FPS, config: cfg}); };
export const Sp: React.FC<{at: number; children: React.ReactNode; from?: number; rot?: number; y?: number; style?: React.CSSProperties}> = ({at, children, from = 0.3, rot = 0, y = 0, style}) => {
  const s = useSp(at);
  if (s <= 0) return null;
  return <div style={{transform: `translateY(${(1 - s) * y}px) scale(${from + (1 - from) * s}) rotate(${(1 - s) * rot}deg)`, opacity: Math.min(1, s * 2), ...style}}>{children}</div>;
};
// beats that punch the camera
export let BEATS: number[] = [0.09, 1.1, 2.77, 3.6, 6.48, 8.24, 9.89, 10.81, 12.38, 16.0, 17.27, 17.77, 18.27, 20.31, 21.61, 22.8, 25.8, 26.97, 29.8, 30.15, 30.55, 31.19, 33.12, 34.78, 35.6, 36.4, 37.64, 39.24, 40.56, 44.39, 47.88, 49.55, 50.84];
export const Stage: React.FC<{children: React.ReactNode}> = ({children}) => {
  const t = useT();
  let punch = 0;
  for (const b of BEATS) if (t >= b && t < b + 0.5) punch = Math.max(punch, Math.exp(-(t - b) * 9));
  const drift = 1 + 0.015 * Math.sin(t * 0.6);
  return <AbsoluteFill style={{color: K.ink, transform: `scale(${drift + punch * 0.035})`}}>{children}</AbsoluteFill>;
};
// zoom-through transition window
export const Seg: React.FC<{from: number; to: number; children: React.ReactNode}> = ({from, to, children}) => {
  const t = useT();
  if (t < from - 0.01 || t > to + 0.3) return null;
  const i = L(t, from, from + 0.28, 0, 1, O3);
  const o = L(t, to, to + 0.28, 0, 1, (v) => v * v);
  return <AbsoluteFill style={{opacity: i * (1 - o), transform: `scale(${(0.9 + 0.1 * i) * (1 + 0.14 * o)})`, filter: i < 1 || o > 0 ? `blur(${(1 - i) * 10 + o * 14}px)` : undefined}}>{children}</AbsoluteFill>;
};
export const glassC = (x?: React.CSSProperties) => ({...glass({padding: '28px 32px'}), color: K.ink, ...x});
export const Ring: React.FC<{show: boolean; r?: number}> = ({show, r = 30}) => (show ? <div style={{position: 'absolute', inset: -8, borderRadius: r, border: `4px solid ${BLUE.b3}`, boxShadow: `0 0 40px rgba(${BLUE.glowRGB},0.8)`}} /> : null);

export const Sparks: React.FC<{at: number; x: number; y: number; n?: number; spread?: number}> = ({at, x, y, n = 18, spread = 260}) => {
  const t = useT();
  const p = L(t, at, at + 0.8, 0, 1, O3);
  if (t < at || p >= 1) return null;
  return <>{Array.from({length: n}).map((_, i) => {
    const a = (i / n) * Math.PI * 2 + random(`sa${at}${i}`), d = spread * (0.5 + random(`sd${at}${i}`) * 0.5) * p;
    return <div key={i} style={{position: 'absolute', left: x + Math.cos(a) * d, top: y + Math.sin(a) * d, width: 10, height: 10, borderRadius: 5, background: i % 3 ? BLUE.b3 : '#fff', opacity: 1 - p, boxShadow: `0 0 12px ${BLUE.b2}`}} />;
  })}</>;
};
export const Blobs: React.FC = () => {
  const t = useT();
  return (
    <AbsoluteFill style={{overflow: 'hidden'}}>
      {[[0.3, 0.25, 520, 0.22], [0.75, 0.55, 600, 0.16], [0.4, 0.8, 480, 0.12]].map(([x, y, r, o], i) => (
        <div key={i} style={{position: 'absolute', left: 1080 * x - r + Math.sin(t * 0.5 + i * 2) * 120, top: 1920 * y - r + Math.cos(t * 0.4 + i) * 140, width: r * 2, height: r * 2, borderRadius: '50%', background: `radial-gradient(circle, rgba(${i === 1 ? BLUE.roseRGB : BLUE.glowRGB},${o}), transparent 70%)`, filter: 'blur(30px)'}} />
      ))}
    </AbsoluteFill>
  );
};

