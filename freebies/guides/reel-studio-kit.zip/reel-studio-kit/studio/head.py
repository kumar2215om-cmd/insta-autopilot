# Write your phrase list here: (start_sec, end_sec, 'caption text').  *word = rose highlight, ^word = blue highlight, _ joins words.
# Get the start/end times from:  python3 seg.py  (speech segments)  +  node ../tools/segs.mjs vo16.wav segs.json hindi  (text per segment)
P = [(0.05, 2.40, 'Ye ek *example caption hai…'),
 (2.80, 5.10, 'apni ^voice ke hisaab se badlo.'),
]
import json, re, numpy as np, soundfile as sf
SPOKEN = {}  # how numbers/acronyms are spoken, e.g. {'$10': 'ten dollar'}
def weight(w):
    core = re.sub(r'[?।.,…"!]', '', w).lstrip('^*'); sp = SPOKEN.get(core, core); return len(sp.replace('_', ' ')) + 2.5
