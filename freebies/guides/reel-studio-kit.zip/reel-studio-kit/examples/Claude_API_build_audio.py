import numpy as np, soundfile as sf, re
from scipy.signal import butter, sosfilt, resample_poly
SR=48000; FPS=30
vo, vsr = sf.read('vo.wav'); DUR = len(vo)/vsr + 0.6; N = int(DUR*SR)
rng = np.random.default_rng(7)

def t_(d): return np.arange(int(d * SR)) / SR
def hp(x, c): return sosfilt(butter(2, c, 'hp', fs=SR, output='sos'), x)
def lp(x, c): return sosfilt(butter(2, c, 'lp', fs=SR, output='sos'), x)
def bp(x, a, b): return sosfilt(butter(2, [a, b], 'bp', fs=SR, output='sos'), x)
def put(buf, x, at, g=1.0):
    i = at if isinstance(at, int) else int(at)
    if i < 0: x = x[-i:]; i = 0
    n = min(len(x), len(buf) - i)
    if n > 0: buf[i:i + n] += x[:n] * g

# ---------- instruments ----------
def kick(d=0.32):
    t = t_(d); ph = 2 * np.pi * np.cumsum(45 + 110 * np.exp(-28 * t)) / SR
    return np.sin(ph) * np.exp(-t / 0.12) + 0.3 * np.sin(ph) * np.exp(-t / 0.02)
def hat(d=0.05): t = t_(d); return hp(rng.standard_normal(len(t)), 7000) * np.exp(-t / 0.012)
def clap(d=0.2):
    t = t_(d); n = bp(rng.standard_normal(len(t)), 900, 3500)
    env = sum(np.exp(-np.clip(t - o, 0, None) / 0.008) * (t >= o) for o in (0, 0.01, 0.022)) + 0.6 * np.exp(-t / 0.07)
    return n * env * 0.6
def pluck(freq, d=0.35):
    t = t_(d); x = np.sign(np.sin(2 * np.pi * freq * t)) * 0.5 + np.sin(2 * np.pi * freq * t)
    return lp(x, 900) * np.exp(-t / 0.13)
def arp(freq, d=0.12):
    t = t_(d); x = (2 * ((freq * t) % 1) - 1)
    return lp(x, 3200) * np.exp(-t / 0.05) * 0.5
def pad(freqs, d):
    t = t_(d); x = sum(np.sin(2 * np.pi * f * t + np.sin(2 * np.pi * 0.3 * t) * 0.5) for f in freqs)
    env = np.minimum(1, t / 0.4) * np.minimum(1, (d - t) / 0.4)
    return lp(x, 1800) * env / len(freqs)
def whoosh(d=0.45, lo=300, hi=6000, rev=False):
    t = t_(d); n = rng.standard_normal(len(t)); out = np.zeros_like(n); y = 0.0
    cut = lo * (hi / lo) ** (t / d); a = 1 - np.exp(-2 * np.pi * cut / SR)
    for i in range(len(n)): y += a[i] * (n[i] - y); out[i] = y
    env = np.sin(np.pi * t / d) ** 2
    out = out * env; return out[::-1] if rev else out
def swish(d=0.16): t = t_(d); return hp(rng.standard_normal(len(t)), 2500) * np.sin(np.pi * t / d) ** 3 * 0.6
def tick(f=3000, d=0.03): t = t_(d); return np.sin(2 * np.pi * f * t) * np.exp(-t / 0.008)
def key():
    t = t_(0.03); c = hp(rng.standard_normal(len(t)), 1800) * np.exp(-t / 0.004)
    return (c + 0.4 * np.sin(2 * np.pi * (1800 + rng.random() * 900) * t) * np.exp(-t / 0.006)) * (0.6 + 0.4 * rng.random())
def click(): t = t_(0.02); return (np.sin(2 * np.pi * 4200 * t) + hp(rng.standard_normal(len(t)), 3000)) * np.exp(-t / 0.003)
def pop(f=900, d=0.09):
    t = t_(d); ph = 2 * np.pi * np.cumsum(f * (1 + 1.5 * np.exp(-t / 0.01))) / SR
    return np.sin(ph) * np.exp(-t / 0.03)
def bounce(d=0.12):
    t = t_(d); ph = 2 * np.pi * np.cumsum(400 - 260 * t / d) / SR
    return np.sin(ph) * np.exp(-t / 0.05) + 0.3 * click()[:len(t)].tolist().__len__() * 0
def impact(d=1.4):
    t = t_(d); ph = 2 * np.pi * np.cumsum(38 + 60 * np.exp(-t / 0.05)) / SR
    sub = np.sin(ph) * np.exp(-t / 0.45)
    nz = lp(rng.standard_normal(len(t)), 1400) * np.exp(-t / 0.12)
    return np.tanh(1.6 * (sub + 0.6 * nz))
def riser(d=1.0):
    t = t_(d); f = 200 * (8 ** (t / d)); ph = 2 * np.pi * np.cumsum(f) / SR
    return (np.sin(ph) * 0.4 + hp(rng.standard_normal(len(t)), 1500) * 0.35) * (t / d) ** 2
def chime(base=1046.5, d=1.4):
    t = t_(d); out = np.zeros_like(t)
    for k, (m, dec) in enumerate([(1, 0.5), (1.5, 0.35), (2, 0.25), (3, 0.15)]):
        out += np.sin(2 * np.pi * base * m * t) * np.exp(-t / dec) / (k + 1)
    return out * 0.5
def glitch(d=0.12):
    t = t_(d); x = np.sign(np.sin(2 * np.pi * 120 * t)) * (rng.random(len(t)) > 0.5)
    x = x * np.repeat(rng.random(len(t) // 240 + 1), 240)[:len(t)]
    return hp(x, 400) * 0.5
def scratch(d=0.18):
    t = t_(d); return bp(rng.standard_normal(len(t)), 1500, 5000) * np.sin(np.pi * t / d) * 0.7


def shutter():
    # camera shutter: two short mechanical clicks + a soft body thump
    t = t_(0.16); out = np.zeros_like(t)
    for o, g in [(0.0, 1.0), (0.055, 0.7)]:
        i = int(o * SR); n = len(t) - i; tt = t[:n]
        out[i:] += bp(rng.standard_normal(n), 1800, 7000) * np.exp(-tt / 0.006) * g
        out[i:] += np.sin(2 * np.pi * 140 * tt) * np.exp(-tt / 0.02) * 0.35 * g
    return out * 0.9
def flick():
    t = t_(0.12); return bp(rng.standard_normal(len(t)), 1200, 6000) * np.sin(np.pi * t / 0.12) ** 2 * 0.7 + np.sin(2 * np.pi * 220 * t) * np.exp(-t / 0.015) * 0.2

fr = lambda s: int(round(s * SR))
S = lambda x, s, g=1.0: put(sfx, x, fr(s), g)
sfx = np.zeros(N); music = np.zeros(N)
src = open('src/Scenes.tsx').read()
pops = sorted(set(float(x) for x in re.findall(r'at=\{([0-9.]+)\}', src)))
for i, t in enumerate(pops): S(pop(650 + (i % 5) * 120, 0.07), t, 0.12)
def keys(a, b, g=0.1):
    n = max(1, int((b - a) / 0.05))
    for k in range(n): S(key(), a + k * (b - a) / n, g)
def ticks(a, b, n, f0=1500, df=40, g=0.08):
    for k in range(n): S(tick(f0 + k * df, 0.015), a + k * (b - a) / n, g)
def ding(at, f=2093, g=0.3): S(chime(f, 0.7), at, g); S(pop(1400, 0.05), at, 0.25)
S(pop(900, 0.05), 0.07, 0.25); S(click(), 2.4, 0.5); S(impact(0.8), 3.1, 0.45); S(glitch(0.12), 3.12, 0.2)
for t in [3.9, 9.7, 14.6, 34.0, 36.2, 48.4]: S(whoosh(0.3, 400, 6000), t - 0.12, 0.26)
S(swish(0.1), 4.6, 0.25); S(scratch(), 6.6, 0.2); ding(7.4, 2349, 0.18)
keys(10.95, 11.9, 0.1); S(click(), 12.4, 0.5); ticks(12.6, 14.3, 24, 1100, 25, 0.04); ding(14.3, 2093, 0.15)
for c in [15.9, 16.6, 17.6, 21.2, 22.9, 23.87, 30.53]: S(click(), c, 0.45)
for t in [14.75, 20.09, 26.27]: S(kick(), t, 0.4); S(pop(1200, 0.05), t, 0.2)
ding(19.0, 2637, 0.22)
keys(27.34, 28.9, 0.1); keys(28.9, 30.1, 0.08); ding(30.6, 2349, 0.18); S(whoosh(0.3, 3000, 300), 31.47, 0.2); S(riser(0.6), 32.4, 0.12)
S(chime(1318, 1.0), 34.84, 0.2); keys(34.6, 35.9, 0.08)
S(glitch(0.15), 37.79, 0.2); S(impact(0.8), 37.85, 0.45); S(scratch(), 40.5, 0.25); ticks(41.0, 43.2, 30, 1000, 20, 0.04)
S(pop(1200, 0.05), 43.8, 0.25); S(pop(900, 0.05), 44.5, 0.2)
keys(49.27, 49.8, 0.14); S(click(), 50.02, 0.5)
for i in range(3): ding(50.1 + i * 0.6, 2349 + i * 80, 0.12)
# light lo-fi bed: soft kick/hat + plucked bass + pad, 92 BPM
BEAT = 60 / 96
roots = [55.0, 49.0, 43.65, 49.0]; chords = [[220, 261.6, 329.6], [196, 246.9, 293.7], [174.6, 220, 261.6], [196, 246.9, 293.7]]
for b in range(int(DUR / BEAT)):
    at = int(b * BEAT * SR); bar = (b // 4) % 4
    put(music, kick() * 0.5, at) if b % 2 == 0 else put(music, clap() * 0.25, at)
    put(music, hat() * 0.25, at + int(BEAT / 2 * SR))
    put(music, pluck(roots[bar]) * 0.4, at)
for i, s0 in enumerate(np.arange(0, DUR, BEAT * 4)):
    put(music, pad([c / 2 for c in chords[i % 4]], BEAT * 4 + 0.05) * 0.4, int(s0 * SR))
music = lp(music, 2500)
v = resample_poly(vo, SR, vsr) if vsr != SR else vo
v = np.pad(v, (0, N - len(v)))[:N]; v = v / np.abs(v).max() * 0.9
env = np.abs(v); k = int(0.1 * SR); env = np.convolve(env, np.ones(k) / k, 'same'); env = np.clip(env / env.max() * 3, 0, 1)
music = music / np.abs(music).max(); sfx = sfx / np.abs(sfx).max()
mix = v + music * 0.10 * (1 - 0.4 * env) + sfx * 0.30
mix = np.tanh(mix * 1.05); mix = mix / np.abs(mix).max() * 10 ** (-1 / 20)
f = int(0.5 * SR); mix[-f:] *= np.linspace(1, 0, f)
sf.write('public/mix.wav', np.stack([mix, mix], 1), SR, subtype='PCM_16'); print('pops', len(pops))
