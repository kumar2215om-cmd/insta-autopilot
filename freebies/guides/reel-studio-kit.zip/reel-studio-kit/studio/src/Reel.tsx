import React from 'react';
import {AbsoluteFill, Audio, staticFile} from 'remotion';
import {useFonts} from './kit';
import {Scenes} from './Scenes';

// clean kit (jayantcreates-style): no big captions, no chapter pill; captions live inside scenes as a small pill
export const Reel: React.FC = () => {
  useFonts();
  return (
    <AbsoluteFill>
      <Scenes />
      <Audio src={staticFile('mix.wav')} />
    </AbsoluteFill>
  );
};
