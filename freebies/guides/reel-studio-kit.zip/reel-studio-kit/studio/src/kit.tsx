import React, {CSSProperties, useEffect, useState} from 'react';
import {AbsoluteFill, continueRender, delayRender, Easing, interpolate, spring, useCurrentFrame} from 'remotion';
import '@fontsource/inter/600.css';
import '@fontsource/inter/800.css';
import '@fontsource/inter/900.css';
import '@fontsource/noto-sans-devanagari/600.css';
import '@fontsource/noto-sans-devanagari/800.css';
import '@fontsource/instrument-serif/400.css';
import '@fontsource/instrument-serif/400-italic.css';
import '@fontsource/jetbrains-mono/500.css';
import '@fontsource/jetbrains-mono/700.css';

export const FPS = 30;
export const K = {
  bg: '#050608', card: 'rgba(255,255,255,0.05)', panel2: 'rgba(255,255,255,0.08)', ink: '#F3F5F9', sub: '#9AA3B2', faint: '#4B5262', line: 'rgba(255,255,255,0.10)',
  orange: '#2F7BFF', orangeL: 'rgba(47,123,255,0.18)', yellow: '#7DD3FC', green: '#22C55E', greenL: 'rgba(34,197,94,0.15)', red: '#F43F5E', redL: 'rgba(244,63,94,0.15)', amber: '#F5B83D', amberL: 'rgba(245,184,61,0.15)', blue: '#38BDF8', blueL: 'rgba(56,189,248,0.14)', dark: '#08090C',
};
export const SANS = "'Inter', 'Noto Sans Devanagari', 'Noto Color Emoji', sans-serif";
export const SERIF = "'Inter', 'Noto Sans Devanagari', sans-serif";
export const MONO = "'JetBrains Mono', monospace";
export const EIN = Easing.bezier(0.16, 1, 0.3, 1);
export const EOUT = Easing.bezier(0.7, 0, 0.84, 0);
export const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
export const ip = (f: number, r: [number, number], o: [number, number], e = EIN) => interpolate(f, r, o, {...cl, easing: e});
export const useT = () => useCurrentFrame() / FPS;
export const at = (s: number) => s * FPS;

export const useFonts = () => {
  const [h] = useState(() => delayRender('fonts'));
  useEffect(() => { document.fonts.ready.then(() => continueRender(h)); }, [h]);
};

export const In: React.FC<{at: number; dy?: number; dur?: number; children: React.ReactNode; style?: CSSProperties; scale?: boolean}> = ({at: a, dy = 36, dur = 0.45, children, style, scale}) => {
  const f = useCurrentFrame();
  if (f < a * FPS) return null;
  const p = ip(f, [a * FPS, (a + dur) * FPS], [0, 1]);
  const s = scale ? spring({frame: f - a * FPS, fps: FPS, config: {damping: 13, stiffness: 170}}) : 1;
  return <div style={{opacity: p, transform: `translateY(${(1 - p) * dy}px) scale(${scale ? 0.7 + 0.3 * s : 1})`, filter: p < 1 ? `blur(${(1 - p) * 6}px)` : undefined, ...style}}>{children}</div>;
};

export const Scene: React.FC<{from: number; to: number; children: React.ReactNode}> = ({from, to, children}) => {
  const f = useCurrentFrame();
  if (f < from * FPS || f >= to * FPS + 7) return null;
  const i = ip(f, [from * FPS, from * FPS + 7], [0, 1]);
  const o = ip(f, [to * FPS, to * FPS + 7], [0, 1], EOUT);
  return <AbsoluteFill style={{opacity: i * (1 - o), transform: `translateY(${(1 - i) * 24 - o * 24}px)`}}>{children}</AbsoluteFill>;
};

export const card = (extra?: CSSProperties): CSSProperties => ({background: 'linear-gradient(180deg, rgba(255,255,255,0.065), rgba(255,255,255,0.03))', borderRadius: 30, border: '1.5px solid rgba(255,255,255,0.10)', boxShadow: '0 30px 80px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.06)', ...extra});

export const Tag: React.FC<{c: string; bg: string; children: React.ReactNode; size?: number}> = ({c, bg, children, size = 26}) => (
  <span style={{display: 'inline-flex', alignItems: 'center', gap: 8, color: c, background: bg, borderRadius: 30, padding: '6px 18px', fontFamily: SANS, fontWeight: 800, fontSize: size, whiteSpace: 'nowrap'}}>{children}</span>
);
export const Mono: React.FC<{children: React.ReactNode; c?: string; size?: number; style?: CSSProperties}> = ({children, c = K.sub, size = 24, style}) => (
  <div style={{fontFamily: MONO, fontWeight: 700, fontSize: size, letterSpacing: 3, color: c, textTransform: 'uppercase', ...style}}>{children}</div>
);
export const Price: React.FC<{v: string; c?: string; size?: number; strike?: number}> = ({v, c = K.ink, size = 150, strike = 0}) => (
  <div style={{position: 'relative', display: 'inline-block', fontFamily: SANS, fontWeight: 900, fontSize: size, color: c, letterSpacing: -size * 0.04, lineHeight: 1}}>
    {v}
    {strike > 0 && <div style={{position: 'absolute', left: -6, top: '52%', height: size * 0.06, width: `calc(${strike * 100}% + 12px)`, background: K.red, borderRadius: 6}} />}
  </div>
);
export const Ok: React.FC<{ok?: boolean; warn?: boolean; s?: number}> = ({ok = true, warn, s = 56}) => (
  <div style={{width: s, height: s, borderRadius: s / 2, background: warn ? K.amber : ok ? K.green : K.red, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0}}>
    <svg width={s * 0.55} height={s * 0.55} viewBox="0 0 30 30">
      {warn ? <path d="M15 6 L15 17 M15 23 L15 24" stroke="#fff" strokeWidth="5" strokeLinecap="round" />
        : ok ? <path d="M5 16 L12 23 L25 8" fill="none" stroke="#fff" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
        : <path d="M7 7 L23 23 M23 7 L7 23" stroke="#fff" strokeWidth="5" strokeLinecap="round" />}
    </svg>
  </div>
);
export const Bg: React.FC = () => (
  <AbsoluteFill style={{background: K.bg, backgroundImage: 'linear-gradient(rgba(255,255,255,0.025) 2px, transparent 2px), linear-gradient(90deg, rgba(255,255,255,0.025) 2px, transparent 2px)', backgroundSize: '72px 72px'}}>
    <AbsoluteFill style={{background: 'radial-gradient(ellipse 80% 60% at 50% 40%, transparent 40%, rgba(0,0,0,0.55) 100%)'}} />
  </AbsoluteFill>
);
