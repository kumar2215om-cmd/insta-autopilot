// Your Instagram handle: shown as the small watermark in every reel.
export const HANDLE = '@your.handle';
