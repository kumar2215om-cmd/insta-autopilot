import {Config} from '@remotion/cli/config';
// Optional: point Remotion at your own Chrome if its bundled browser can't run on your machine.
if (process.env.BROWSER_EXECUTABLE) Config.setBrowserExecutable(process.env.BROWSER_EXECUTABLE);
