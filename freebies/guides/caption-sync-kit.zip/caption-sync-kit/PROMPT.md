Paste in Claude Code (inside your Remotion project, with this kit folder next to it):

Sync my reel captions with caption-sync-kit (local, no AI model).
Files: voice = [public/vo.wav], script = [my script below / path], kit = [path to caption-sync-kit].
1. Write script.txt: one line per phrase I say in one breath (new line wherever the voice pauses). Keep my exact words; mark 1–2 keywords per line with * (pink) or ^ (blue); join multi-word names with _.
2. If my script has numbers or acronyms, write spoken.json with how they are said (e.g. "$10": "ten dollar").
3. Run: python3 captions_sync.py [voice] script.txt -o public/captions.json --spoken spoken.json
4. Read the report. For any "⚠ check" line, listen to that time range; fix by splitting/merging lines in script.txt where the voice really pauses, then re-run. Never invent words that are not spoken.
5. Copy Captions.tsx into src/, render it with <Captions data={caps} top={1345} /> using my brand colours, keep it inside Instagram safe zones.
6. Render 3 stills (start, middle, near a keyword) and check them yourself. Show me before rendering the full video.
