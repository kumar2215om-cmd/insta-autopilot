---
name: reel-studio
description: Make a complete 9:16 Hinglish Instagram reel from one line ("reel banao: <topic>") using this kit: script, voice, word-synced captions, Remotion scenes, sound design, render, silence cut, 1.1x, self-check, caption. Use when the user asks to make/edit a reel in this folder.
---
# Reel Studio (Reel Studio Kit)

Folder layout: `studio/` (Remotion project), `tools/` (cut_silence.py, segs.mjs = offline Whisper), `examples/` (finished scene files to copy patterns from), `render.sh`, `setup_check.sh`.

## When the user says `reel banao: <topic>` (or `setup check karo`)
0. Set the user's handle in `studio/src/brand.ts` (ask once). If `studio/node_modules` or `tools/node_modules` is missing, run `bash setup_check.sh` first and fix anything marked ✗.
1. **Script first, wait for approval.** Write a 35–50 s Hinglish script (Devanagari Hindi + English words in Latin): HOOK (0–3 s) → "Here's how it actually works." → 3–5 beats → honest catch → CTA (comment keyword + share line). Give 3 hook options. Flag any claim you could not verify. Then an **ElevenLabs-ready** copy: numbers as words, acronyms spaced ("A P I"), "…" and "।" for pauses. **Stop and wait** until the user approves.
2. **Voice.** Ask for the voice file (ElevenLabs export, OpenAI TTS, or their own recording) → `ffmpeg -i voice.mp3 -ar 48000 -ac 1 studio/vo.wav && cp studio/vo.wav studio/public/vo.wav`.
3. **Timing.** `cd studio && python3 seg.py` (prints speech segments, writes segs.json; aim est ≤ 54 s). Then `ffmpeg -i vo.wav -ar 16000 vo16.wav && node ../tools/segs.mjs vo16.wav segs.json hindi` (try `english` too if text looks wrong). Write the phrase list `P = [(start, end, 'text with *rose ^blue words'), …]` at the top of `head.py` (+ `SPOKEN` dict), then `cat head.py tail.py > timing.py && python3 timing.py` → `src/data.json`.
4. **Scenes.** Rewrite `src/Scenes.tsx`: one `<Beat a b>` per script section, timed to the phrase starts; cards / stamps / app mock-ups that show exactly what the voice says; captions stay at top 1345. Copy patterns from `examples/`. Never leave blank placeholder cards. Call hooks (useSp…) before any early `return null`.
5. **Self-check before render.** `COLS=6 node stills.mjs 30,120,240,… out/sheet.png` (frames = seconds×30), look at the sheet, fix overlaps/overflow/empty moments.
6. **Sound.** Edit the cue block in `build_audio.py` (whoosh on every beat change, impact on stamps, keys while typing, ding on reveals).
7. **Render.** `bash render.sh` → `deliver/Reel.mp4` (−14 LUFS, silences cut, 1.1x) + `deliver/contact_sheet.png`. Look at the contact sheet; if anything is wrong, fix and re-render.
8. **Deliver.** Write `deliver/Caption.txt` (hook line, 3–6 value lines, honest catch, comment keyword CTA, follow line, 8–12 hashtags) and tell the user where everything is.

## House style (change freely)
Cream `#F1EADC` with line-art skyline (`LiveBg.tsx`), ink `#1C1A17`, rose `#FF2D95` for emphasis, cerulean `#007BA7` for steps, green only for ✓. White cards with soft shadows. Anton for big numbers, Inter for UI. No dark themes, no transitions unless asked.

## Editor mode
If the user says things like "hook aur punchy karo", "captions bade karo", "beat 3 slow hai": edit the relevant file (script / head.py / Scenes.tsx / build_audio.py), re-check stills, re-render.
