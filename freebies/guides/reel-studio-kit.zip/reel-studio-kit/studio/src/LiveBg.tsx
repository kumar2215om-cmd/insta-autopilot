// Live line-art background for the cream clean kit (improved over the reference):
// 3 Indian scenes that draw on stroke-by-stroke and hand over to each other, flapping birds, drifting clouds,
// a slow sun, waves, a waving flag + kite, and a line-drawn auto-rickshaw crossing the ground now and then.
import React from 'react';
import {AbsoluteFill} from 'remotion';
import {MONO, useT} from './kit';
import {L, O3} from './motion';
import {HANDLE} from './brand';

const INK = '#C3AE8E', SOFT = '#D6C6AC', BASE = 1500; // skyline band starts at y=1500 (local y 0..260)
const CYCLE = 8; // seconds per scene

// each scene = list of static paths (local coords 1080 x 260, ground at y=250)
const SCENES: string[][] = [
  [ // city: India-Gate style arch, domed tomb with minarets, buildings
    'M20 250 H1060',
    'M60 250 V175 H120 V250 M140 250 V205 H185 V250',
    'M250 250 V110 H370 V250 M250 110 H370 M262 98 H358 M285 250 V175 Q310 140 335 175 V250',
    'M470 250 V150 H650 V250 M500 150 Q560 70 620 150 M560 82 V64 M440 250 V110 M680 250 V110 M440 110 l-6 -12 h12 z M680 110 l-6 -12 h12 z M535 250 V200 Q560 180 585 200 V250',
    'M760 250 V140 H820 V250 M840 250 V185 H900 V250 M920 250 V160 H975 V250 M995 250 V205 H1040 V250',
  ],
  [ // seaside: palms, hut on a hill, boat
    'M20 250 H1060',
    'M150 250 Q138 165 172 85 M172 85 Q112 65 82 95 M172 85 Q225 52 268 74 M172 85 Q145 42 124 30 M172 85 Q215 95 236 128',
    'M330 250 Q322 190 342 140 M342 140 Q302 128 284 146 M342 140 Q376 118 404 132 M342 140 Q330 110 318 102',
    'M600 250 Q760 140 1040 205 L1060 250 M790 196 V146 L842 108 L894 146 V190 M812 160 H842 V196',
    'M470 230 h90 l-14 16 h-62 z M515 230 V178 l32 40 z',
  ],
  [ // temple town: shikhara temple, houses, tree
    'M20 250 H1060',
    'M380 250 V170 H520 V250 M395 170 Q450 40 505 170 M450 72 V40 M420 250 V205 Q450 185 480 205 V250',
    'M110 250 V190 L150 160 L190 190 V250 M230 250 V200 H300 V250 M240 200 L265 180 L290 200',
    'M620 250 V180 H700 V250 M720 250 V200 H790 V250 M640 180 L660 160 L680 180',
    'M900 250 V200 M900 200 Q860 190 870 160 Q890 130 920 150 Q960 140 955 180 Q950 205 900 200',
  ],
];

const Stroke: React.FC<{d: string; draw: number; w?: number; c?: string}> = ({d, draw, w = 3, c = INK}) => (
  draw <= 0 ? null : <path d={d} fill="none" stroke={c} strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - draw} />
);

const Bird: React.FC<{x: number; y: number; t: number; i: number; s?: number}> = ({x, y, t, i, s = 1}) => {
  const f = 0.25 + 0.75 * Math.abs(Math.sin(t * 5.5 + i * 1.3));
  const w = 16 * s, h = 10 * s * f;
  return <path d={`M${x - w} ${y} Q${x - w / 2} ${y - h} ${x} ${y} Q${x + w / 2} ${y - h} ${x + w} ${y}`} fill="none" stroke={INK} strokeWidth={2.6} strokeLinecap="round" />;
};

const Cloud: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <path d={`M${x} ${y} q ${10 * s} ${-22 * s} ${32 * s} ${-12 * s} q ${12 * s} ${-26 * s} ${40 * s} ${-8 * s} q ${26 * s} ${-6 * s} ${26 * s} ${20 * s} z`} fill="none" stroke={SOFT} strokeWidth={2.5} strokeLinejoin="round" />
);

const Rickshaw: React.FC<{x: number; y: number; t: number}> = ({x, y, t}) => {
  const b = Math.sin(t * 18) * 1.2;
  return (
    <g transform={`translate(${x} ${y + b})`} fill="none" stroke={INK} strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round">
      <path d="M0 -10 V-42 Q2 -56 20 -58 H58 Q74 -56 76 -40 V-10 Z" />
      <path d="M58 -58 V-10 M20 -50 H52 V-28 H20 Z" />
      <circle cx={12} cy={-6} r={8} /><circle cx={64} cy={-6} r={8} />
    </g>
  );
};

export const LiveBg: React.FC<{bg?: string}> = ({bg = '#F1EADC'}) => {
  const t = useT();
  const k = Math.floor(t / CYCLE) % SCENES.length, u = (t % CYCLE) / CYCLE;
  const scene = SCENES.at(k), n = scene.length;
  // draw stroke-by-stroke in the first 40% of the cycle, hold, erase in reverse in the last 15%
  const drawOf = (i: number) => u < 0.85 ? L(u, 0.02 + (i / n) * 0.3, 0.12 + (i / n) * 0.3, 0, 1, O3) : L(u, 0.85 + ((n - 1 - i) / n) * 0.12, 0.88 + ((n - 1 - i) / n) * 0.12, 1, 0);
  const sunY = 1430 - 70 * Math.sin((t / 40) * Math.PI);
  const rx = ((t % 14) / 14) * 1400 - 160; // rickshaw crosses every 14s
  const waves = Array.from({length: 2}).map((_, j) => `M0 ${1738 + j * 12} ` + Array.from({length: 28}).map((_, q) => `q 20 ${(q % 2 ? 6 : -6) * Math.sin(t * 2 + j)} 40 0`).join(' '));
  return (
    <AbsoluteFill style={{background: bg}}>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse 80% 55% at 50% 35%, rgba(255,255,255,0.45), transparent 70%)'}} />
      <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
        {/* sun + clouds behind the skyline */}
        <circle cx={860} cy={sunY} r={56} fill="none" stroke={SOFT} strokeWidth={2.5} />
        <Cloud x={((t * 14) % 1300) - 150} y={1385} s={1.1} />
        <Cloud x={((t * 9 + 600) % 1300) - 150} y={175} s={0.9} />
        <Cloud x={((t * 11 + 200) % 1300) - 150} y={1300} s={0.7} />
        {/* flock of birds drifting across the top + one pair low */}
        {[[0, 140, 1], [40, 120, 0.8], [75, 150, 0.9], [-30, 160, 0.7]].map(([dx, y, s], i) => <Bird key={i} t={t} i={i} s={s} x={((t * 38 + dx + 200) % 1300) - 100} y={y + Math.sin(t * 1.5 + i) * 6} />)}
        {[[0, 1340], [36, 1325]].map(([dx, y], i) => <Bird key={`b${i}`} t={t} i={i + 7} s={0.8} x={1180 - ((t * 30 + dx) % 1350)} y={y + Math.sin(t * 2 + i) * 5} />)}
        {/* skyline scene */}
        <g transform={`translate(0 ${BASE})`}>{scene.map((d, i) => <Stroke key={`${k}-${i}`} d={d} draw={drawOf(i)} />)}</g>
        {/* scene extras: waves + boat bob (seaside), waving flag + kite (temple) */}
        {k === 1 && u < 0.9 && waves.map((d, j) => <path key={j} d={d} fill="none" stroke={SOFT} strokeWidth={2.2} opacity={L(u, 0.1, 0.25, 0, 1) * L(u, 0.8, 0.9, 1, 0)} />)}
        {k === 2 && u > 0.3 && u < 0.88 && (
          <g opacity={L(u, 0.3, 0.4, 0, 1) * L(u, 0.8, 0.88, 1, 0)}>
            <path d={`M${450} ${BASE + 40} q 14 ${-8 + 6 * Math.sin(t * 6)} 28 0 q -14 ${8 + 6 * Math.sin(t * 6 + 1)} -28 12`} fill="none" stroke={INK} strokeWidth={2.4} />
            <path d={`M${780 + 20 * Math.sin(t * 0.8)} ${1330 + 12 * Math.sin(t * 1.3)} l 26 26 l -26 26 l -26 -26 z`} fill="none" stroke={INK} strokeWidth={2.4} />
            <path d={`M${780 + 20 * Math.sin(t * 0.8)} ${1382 + 12 * Math.sin(t * 1.3)} Q ${720} ${1520} ${560} ${BASE + 120}`} fill="none" stroke={SOFT} strokeWidth={1.6} />
          </g>
        )}
        {/* auto-rickshaw driving along the ground */}
        <Rickshaw x={rx} y={BASE + 250} t={t} />
      </svg>
      <div style={{position: 'absolute', top: 1455, left: 0, right: 0, display: 'flex', justifyContent: 'center'}}><div style={{fontFamily: MONO, fontWeight: 700, fontSize: 20, letterSpacing: 3, color: '#8A7B66', background: 'rgba(0,0,0,0.05)', borderRadius: 20, padding: '6px 16px'}}>{HANDLE.toUpperCase()}</div></div>
    </AbsoluteFill>
  );
};
