// Claude_API: idea from krishna.ai_9 De8WRqmjtBB, rebuilt in cream/rose. Claude Desktop developer mode -> third-party inference
// (gateway URL + API key) so Claude Code runs without a subscription, with the honest beat: not free, pay per use.
import React from 'react';
import {AbsoluteFill, useCurrentFrame, spring} from 'remotion';
import '@fontsource/anton/400.css';
import '@fontsource/source-serif-4/600.css';
import {SANS, MONO, FPS, useT} from './kit';
import {L, O3, IO} from './motion';
import {Logo} from './logos';
import {LiveBg} from './LiveBg';
import data from './data.json';

const INK = '#1C1A17', ROSE = '#FF2D95', CER = '#007BA7', MUTE = '#8C8780', GREEN = '#16A34A', RED = '#E5484D', CL = '#D97757';
const DISP = "'Anton', 'Inter', sans-serif", SERIF = "'Source Serif 4', Georgia, serif";
const useSp = (at: number, cfg = {damping: 14, stiffness: 160}) => { const f = useCurrentFrame(); return f < at * FPS ? 0 : spring({frame: f - at * FPS, fps: FPS, config: cfg}); };
const Row: React.FC<{children: React.ReactNode; gap?: number; style?: React.CSSProperties}> = ({children, gap = 12, style}) => <div style={{display: 'flex', alignItems: 'center', gap, ...style}}>{children}</div>;
const Pop: React.FC<{at: number; children: React.ReactNode; style?: React.CSSProperties}> = ({at, children, style}) => { const s = useSp(at); if (s <= 0) return null; return <div style={{transform: `translateY(${(1 - s) * 22}px) scale(${0.8 + 0.2 * s})`, opacity: Math.min(1, s * 2), filter: `blur(${Math.max(0, 1 - s * 1.5) * 8}px)`, ...style}}>{children}</div>; };
const Abs: React.FC<{top: number; children: React.ReactNode}> = ({top, children}) => <div style={{position: 'absolute', top, left: 0, right: 0, display: 'flex', justifyContent: 'center'}}>{children}</div>;
const Beat: React.FC<{a: number; b: number; children: React.ReactNode}> = ({a, b, children}) => { const t = useT(); if (t < a || t >= b) return null; const o = L(t, b - 0.12, b, 1, 0); return <AbsoluteFill style={{opacity: o, filter: `blur(${(1 - o) * 8}px)`, transform: 'translateY(50px) scale(1.08)', transformOrigin: '540px 0px'}}>{children}</AbsoluteFill>; };
const Card: React.FC<{children: React.ReactNode; w?: number; style?: React.CSSProperties}> = ({children, w = 800, style}) => <div style={{width: w, boxSizing: 'border-box', borderRadius: 26, padding: '22px 26px', background: '#fff', color: INK, fontFamily: SANS, boxShadow: '0 26px 54px rgba(60,40,20,0.18)', ...style}}>{children}</div>;
const Stamp: React.FC<{at: number; c?: string; rot?: number; children: React.ReactNode; size?: number}> = ({at, c = ROSE, rot = -6, children, size = 72}) => { const s = useSp(at, {damping: 9, stiffness: 220}); if (s <= 0) return null;
  return <div style={{transform: `scale(${2.2 - 1.2 * s}) rotate(${rot}deg)`, opacity: Math.min(1, s * 3), display: 'inline-block', border: `7px solid ${c}`, color: c, background: '#fff', borderRadius: 18, padding: '4px 28px', fontFamily: DISP, fontSize: size, boxShadow: '0 16px 34px rgba(60,40,20,0.2)'}}>{children}</div>; };
const type = (t: number, a: number, b: number, s: string) => s.slice(0, Math.max(0, Math.round(L(t, a, b, 0, s.length))));
const Cursor: React.FC<{x: number; y: number; click?: boolean}> = ({x, y, click}) => <div style={{position: 'absolute', left: x, top: y, zIndex: 50, transform: `scale(${click ? 0.85 : 1})`}}><svg width={44} height={52} viewBox="0 0 22 26"><path d="M2 2 L2 20 L7 15 L10 23 L13 22 L10 14 L17 14 Z" fill={INK} stroke="#fff" strokeWidth={1.6} strokeLinejoin="round" /></svg>{click && <div style={{position: 'absolute', left: -14, top: -14, width: 40, height: 40, borderRadius: 20, border: `3px solid ${ROSE}`, opacity: 0.8}} />}</div>;
// cursor path: list of [time, x, y]; clicks at given times
const usePath = (pts: [number, number, number][]) => { const t = useT(); let x = pts[0][1], y = pts[0][2];
  for (let i = 1; i < pts.length; i++) if (t >= pts[i - 1][0]) { const p = L(t, pts[i - 1][0], pts[i][0], 0, 1, IO); x = pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * p; y = pts[i - 1][2] + (pts[i][2] - pts[i - 1][2]) * p; }
  return [x, y]; };
const StepPill: React.FC<{n: number; label: string; at: number}> = ({n, label, at}) => <Abs top={160}><Pop at={at}><Row gap={14}><span style={{fontFamily: DISP, fontSize: 60, color: '#fff', background: ROSE, borderRadius: 18, padding: '0 22px'}}>STEP {n}</span><span style={{fontFamily: SANS, fontWeight: 900, fontSize: 42, color: INK}}>{label}</span></Row></Pop></Abs>;

// Claude Desktop window (light)
const Win: React.FC<{children?: React.ReactNode; h?: number; tab?: string}> = ({children, h = 640, tab}) =>
  <div style={{width: 940, height: h, borderRadius: 26, background: '#FAF9F5', boxShadow: '0 30px 70px rgba(60,40,20,0.25)', overflow: 'hidden', position: 'relative', fontFamily: SANS, color: INK}}>
    <Row gap={14} style={{height: 64, padding: '0 22px', background: '#F0EEE6', borderBottom: '1.5px solid #E4E0D5'}}><span style={{fontSize: 30, letterSpacing: 2, color: MUTE, fontWeight: 900}}>•••</span><Logo name="claude" s={30} tile={false} /><span style={{fontFamily: SERIF, fontSize: 30, fontWeight: 600}}>Claude</span>
      <Row gap={22} style={{marginLeft: 'auto', fontSize: 22, color: MUTE}}>{['Chat', 'Cowork', 'Code'].map((s) => <span key={s} style={{background: tab === s ? CL : 'transparent', color: tab === s ? '#fff' : MUTE, borderRadius: 8, padding: '2px 10px', fontWeight: 700}}>{s}</span>)}</Row></Row>
    <div style={{position: 'absolute', top: 64, left: 0, right: 0, bottom: 0}}>{children}</div>
  </div>;
const Home: React.FC<{text?: string; title?: string}> = ({text, title = 'How can I help you today?'}) => <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', paddingTop: 110}}>
  <Logo name="claude" s={80} tile={false} /><div style={{fontFamily: SERIF, fontSize: 46, fontWeight: 600, marginTop: 16}}>{title}</div>
  <div style={{width: 760, height: 96, borderRadius: 22, background: '#fff', border: '1.5px solid #E4E0D5', marginTop: 34, padding: '20px 24px', boxSizing: 'border-box', fontSize: 26, color: text ? INK : '#B4ADA2'}}>{text || 'Reply to Claude…'}</div></div>;
const Menu: React.FC<{items: [string, boolean?, string?][]; x: number; y: number; w?: number}> = ({items, x, y, w = 300}) => <div style={{position: 'absolute', left: x, top: y, width: w, background: '#fff', borderRadius: 14, boxShadow: '0 18px 40px rgba(60,40,20,0.25)', padding: 8, zIndex: 20}}>
  {items.map(([s, hi, badge]) => <Row key={s} gap={8} style={{padding: '10px 14px', borderRadius: 10, fontSize: 24, fontWeight: 700, background: hi ? CL : 'transparent', color: hi ? '#fff' : INK}}>{s}{badge && <span style={{fontSize: 14, background: GREEN, color: '#fff', borderRadius: 6, padding: '1px 6px'}}>{badge}</span>}<span style={{marginLeft: 'auto', opacity: 0.5}}>{s.endsWith('…') ? '' : '›'}</span></Row>)}</div>;

// ---------- A hook 0–3.9 ----------
const A: React.FC = () => { const t = useT(); const [x, y] = usePath([[0, 760, 700], [1.6, 760, 700], [2.4, 640, 560]]);
  return <>
    <Abs top={280}><Pop at={0.07}><Card w={820} style={{position: 'relative'}}><Row gap={10}><Logo name="claude" s={34} tile={false} /><span style={{fontFamily: SERIF, fontSize: 34, fontWeight: 600}}>Claude</span></Row>
      <div style={{fontSize: 26, color: MUTE, marginTop: 14}}>Your plan</div><Row style={{justifyContent: 'space-between'}}><b style={{fontSize: 52}}>Pro</b><span style={{fontFamily: DISP, fontSize: 60}}>$20<span style={{fontSize: 30, color: MUTE}}>/month</span></span></Row>
      <Row gap={14} style={{marginTop: 16}}><span style={{border: '2px solid #E4E0D5', borderRadius: 12, padding: '8px 18px', fontSize: 24, fontWeight: 700}}>Manage</span><span style={{border: `2px solid ${RED}`, color: RED, borderRadius: 12, padding: '8px 18px', fontSize: 24, fontWeight: 700, background: t >= 2.4 ? '#FDECEC' : '#fff'}}>Cancel plan</span></Row></Card></Pop></Abs>
    {t < 3.1 && <div style={{position: 'absolute', left: 0, top: 0}}><Cursor x={x} y={y} click={t >= 2.4 && t < 2.6} /></div>}
    {t >= 3.1 && <Abs top={760}><Stamp at={3.1} rot={-5}>WAIT ✋ ये देखो</Stamp></Abs>}
  </>; };

// ---------- B hidden setting 3.9–9.7 ----------
const B: React.FC = () => { const t = useT();
  return <>
    <Abs top={200}><Pop at={4.08}><Win h={560}><Home /></Win></Pop></Abs>
    {t >= 4.6 && <div style={{position: 'absolute', left: 820, top: 230}}><Pop at={4.6}><div style={{fontSize: 90, transform: `rotate(${Math.sin(t * 3) * 8}deg)`}}>🔒</div></Pop></div>}
    {t >= 6.43 && <Abs top={830}><Row gap={18}><Pop at={6.43}><Row gap={10} style={{background: '#fff', borderRadius: 40, padding: '12px 26px', fontWeight: 900, fontSize: 34, boxShadow: '0 10px 22px rgba(60,40,20,0.12)', textDecoration: 'line-through', color: MUTE}}>Pro plan</Row></Pop><Pop at={7.4}><Row gap={10} style={{background: '#E8F7EE', color: GREEN, borderRadius: 40, padding: '12px 26px', fontWeight: 900, fontSize: 34, border: `3px solid ${GREEN}`}}>Claude Code ✓</Row></Pop></Row></Abs>}
  </>; };

// ---------- C step 1 9.7–14.6 ----------
const C: React.FC = () => { const t = useT(); const p = Math.round(L(t, 12.6, 14.3, 0, 97)); const [x, y] = usePath([[10.95, 760, 900], [11.9, 330, 660], [14, 330, 660]]);
  return <>
    <StepPill n={1} label="Download" at={9.9} />
    <Abs top={330}><Pop at={10.95}><div style={{width: 940, borderRadius: 24, background: '#fff', boxShadow: '0 30px 70px rgba(60,40,20,0.22)', overflow: 'hidden', fontFamily: SANS}}>
      <Row gap={10} style={{padding: '14px 20px', background: '#F0EEE6'}}>{['#FF5F57', '#FEBC2E', '#28C840'].map((c) => <span key={c} style={{width: 14, height: 14, borderRadius: 7, background: c}} />)}<span style={{marginLeft: 14, background: '#fff', borderRadius: 10, padding: '6px 16px', fontFamily: MONO, fontSize: 22, flex: 1}}>{type(t, 10.95, 11.9, 'claude.com/download')}</span></Row>
      <div style={{padding: '40px 40px 50px', textAlign: 'center'}}><div style={{fontFamily: SERIF, fontSize: 58, fontWeight: 600}}>Download Claude</div><div style={{fontSize: 24, color: MUTE, marginTop: 8}}>Desktop app for Windows and macOS</div>
        <Row gap={16} style={{justifyContent: 'center', marginTop: 28}}><span style={{background: INK, color: '#fff', borderRadius: 12, padding: '14px 26px', fontSize: 24, fontWeight: 800, transform: `scale(${t >= 12.4 && t < 12.6 ? 0.92 : 1})`}}>Download for Windows</span><span style={{border: '2px solid #E4E0D5', borderRadius: 12, padding: '14px 26px', fontSize: 24, fontWeight: 700}}>macOS</span></Row></div></div></Pop></Abs>
    {t < 13 && <div style={{position: 'absolute', left: 0, top: 0}}><Cursor x={x} y={y} click={t >= 12.4 && t < 12.6} /></div>}
    {t >= 12.6 && <Abs top={830}><Pop at={12.6}><Card w={640} style={{padding: '16px 22px'}}><Row style={{justifyContent: 'space-between', fontSize: 26, fontWeight: 800}}><span>⬇️ Claude Setup</span><span style={{fontFamily: MONO, color: CER}}>{p}%</span></Row><div style={{height: 12, borderRadius: 6, background: '#ECE6DC', marginTop: 10}}><div style={{width: `${p}%`, height: '100%', borderRadius: 6, background: CER}} /></div></Card></Pop></Abs>}
  </>; };

// ---------- D steps 2–4 14.6–34.0 (one persistent window) ----------
const D: React.FC = () => { const t = useT();
  const s2 = t < 20.0, s3 = t >= 20.0 && t < 26.2, s4 = t >= 26.2;
  // cursor (window-local coords; window at left 70, top 330)
  const [cx, cy] = usePath([[14.75, 500, 400], [15.6, 30, 20], [15.9, 30, 20], [16.4, 120, 260], [16.7, 120, 260], [17.2, 400, 260], [18.2, 420, 330], [19.6, 420, 330], [21.2, 30, 20], [21.8, 140, 220], [22.6, 420, 220], [24.2, 420, 220], [26.6, 600, 400], [27.4, 500, 330], [30.2, 760, 520], [31.2, 760, 520]]);
  const click = [15.9, 16.6, 17.6, 21.2, 22.9, 23.87, 30.53].some((c) => t >= c && t < c + 0.2);
  const devOn = t >= 19.0;
  const menu1 = s2 && t >= 15.9; const help = s2 && t >= 16.6; const tro = s2 && t >= 17.2;
  const menu3 = s3 && t >= 21.2 && t < 24.2; const devSub = s3 && t >= 22.3 && t < 24.2;
  const dialog = (s3 && t >= 24.2) || (s4 && t < 31.4);
  const closing = L(t, 31.47, 32.0, 1, 0, IO); const reopen = L(t, 32.6, 33.3, 0, 1, O3);
  const winScale = t < 31.47 ? 1 : t < 32.6 ? 0.85 + 0.15 * closing : 0.85 + 0.15 * reopen; const winOp = t < 31.47 ? 1 : t < 32.6 ? closing : reopen;
  const url = type(t, 27.34, 28.9, 'https://my-gateway.example/v1'), key = '•'.repeat(Math.max(0, Math.round(L(t, 28.9, 30.1, 0, 18))));
  return <>
    {s2 && <StepPill n={2} label="Developer Mode" at={14.75} />}
    {s3 && <StepPill n={3} label="Third-party inference" at={20.09} />}
    {s4 && <StepPill n={4} label="Gateway + API key" at={26.27} />}
    <div style={{position: 'absolute', left: 70, top: 330, transform: `scale(${winScale})`, opacity: winOp, transformOrigin: '470px 320px'}}>
      <Pop at={14.75}><Win h={680}><Home />
        {menu1 && <Menu x={14} y={4} items={[['File'], ['Edit'], ['View'], ...(devOn ? [['Developer', false, 'NEW'] as [string, boolean, string]] : []), ['Help', help]]} />}
        {help && <Menu x={318} y={190} w={330} items={[['Check for Updates…'], ['Troubleshooting', tro], ['About Claude…']]} />}
        {tro && <Menu x={652} y={240} w={290} items={[['Open Logs Folder…'], ['Enable Developer Mode…', t >= 17.59], ['Clear Cache…']]} />}
        {menu3 && <Menu x={14} y={4} items={[['File'], ['Edit'], ['View'], ['Developer', devSub, 'NEW'], ['Help']]} />}
        {devSub && <Menu x={318} y={150} w={460} items={[['Configure Third-Party Inference…', t >= 23.87], ['Open MCP Log File…'], ['Reload MCP Configuration…']]} />}
        {dialog && <div style={{position: 'absolute', inset: 0, background: 'rgba(28,26,23,0.25)', display: 'flex', alignItems: 'center', justifyContent: 'center'}}><Pop at={24.2}><div style={{width: 760, background: '#fff', borderRadius: 20, padding: '24px 28px', boxShadow: '0 24px 50px rgba(0,0,0,0.25)'}}>
          <b style={{fontSize: 30}}>Configure third-party inference</b>
          {[['Connection', 'Gateway (Anthropic-compatible) ▾', true], ['Credential kind', 'Static API key ▾', true], ['Gateway base URL', url || 'https://', t >= 27.34 && t < 28.9], ['Gateway API key', key, t >= 28.9 && t < 30.1]].map(([l, v, act]) => <div key={l as string} style={{marginTop: 14}}><div style={{fontSize: 18, color: MUTE, fontWeight: 700}}>{l}</div><div style={{marginTop: 4, border: `2px solid ${act && (l as string).startsWith('Gateway') ? CL : '#E4E0D5'}`, borderRadius: 10, padding: '10px 14px', fontFamily: MONO, fontSize: 22, minHeight: 28}}>{v}</div></div>)}
          <Row style={{justifyContent: 'flex-end', marginTop: 18}}><span style={{background: t >= 30.53 ? GREEN : CL, color: '#fff', borderRadius: 10, padding: '10px 22px', fontWeight: 800, fontSize: 22}}>{t >= 30.53 ? 'Applied ✓' : 'Apply locally'}</span></Row>
        </div></Pop></div>}
        <Cursor x={cx} y={cy} click={click} />
      </Win></Pop>
    </div>
    {s2 && devOn && <Abs top={1080}><Pop at={19.0}><span style={{background: '#E8F7EE', color: GREEN, border: `2px solid ${GREEN}`, borderRadius: 30, padding: '10px 24px', fontWeight: 900, fontSize: 30, fontFamily: SANS}}>✓ Developer Mode enabled</span></Pop></Abs>}
    {t >= 31.47 && t < 33.6 && <Abs top={1080}><Pop at={31.47}><span style={{background: '#fff', borderRadius: 30, padding: '10px 24px', fontWeight: 900, fontSize: 30, fontFamily: SANS, boxShadow: '0 10px 22px rgba(60,40,20,0.12)'}}>{t < 32.6 ? 'Quit Claude ✕' : 'Reopen ↻'}</span></Pop></Abs>}
  </>; };

// ---------- E ready 34.0–36.2 ----------
const E: React.FC = () => { const t = useT();
  return <>
    <Abs top={260}><Pop at={34.15}><Win h={600} tab="Code"><Home title="Claude Code is ready" text={type(t, 34.6, 35.9, 'Build a landing page for my reels…')} /></Win></Pop></Abs>
    {t >= 34.84 && <Abs top={940}><Pop at={34.84}><span style={{background: '#E8F7EE', color: GREEN, border: `2px solid ${GREEN}`, borderRadius: 30, padding: '10px 24px', fontWeight: 900, fontSize: 32, fontFamily: SANS}}>✓ CONNECTED · via your gateway</span></Pop></Abs>}
  </>; };

// ---------- F honest 36.2–48.4 ----------
const F: React.FC = () => { const t = useT(); const cost = L(t, 41.0, 43.2, 0, 3.4, O3); const tok = Math.round(L(t, 41.0, 43.2, 0, 820000, O3));
  return <>
    <Abs top={170}><Stamp at={37.79} c={RED} rot={-4}>FREE ✕ नहीं है</Stamp></Abs>
    {t >= 39.13 && <Abs top={400}><Row gap={24} style={{alignItems: 'stretch'}}>
      <Pop at={39.13}><Card w={400} style={{height: '100%'}}><div style={{fontFamily: MONO, fontWeight: 700, fontSize: 20, color: MUTE}}>SUBSCRIPTION</div><div style={{fontFamily: DISP, fontSize: 84, marginTop: 6, textDecoration: t >= 40.5 ? 'line-through' : 'none', color: t >= 40.5 ? MUTE : INK}}>$20</div><div style={{fontSize: 26, color: MUTE, fontWeight: 700}}>every month, fixed</div></Card></Pop>
      {t >= 40.5 && <Pop at={40.5}><Card w={440} style={{border: `3px solid ${CER}`}}><div style={{fontFamily: MONO, fontWeight: 700, fontSize: 20, color: CER}}>API · PAY PER USE</div><div style={{fontFamily: DISP, fontSize: 84, marginTop: 6, color: CER}}>${cost.toFixed(2)}</div><div style={{fontSize: 22, color: MUTE, fontWeight: 700}}>{tok.toLocaleString('en-US')} tokens · example</div>
        <div style={{height: 14, borderRadius: 7, background: '#ECE6DC', marginTop: 12}}><div style={{width: `${(cost / 3.4) * 100}%`, height: '100%', borderRadius: 7, background: CER}} /></div></Card></Pop>}
    </Row></Abs>}
    {t >= 43.8 && <Abs top={770}><Pop at={43.8}><Row gap={16} style={{fontFamily: SANS, fontWeight: 900, fontSize: 32}}><span style={{background: '#E8F7EE', color: GREEN, borderRadius: 30, padding: '10px 22px'}}>Light use → सस्ता ✓</span><span style={{background: '#FDECEC', color: RED, borderRadius: 30, padding: '10px 22px'}}>Heavy coding → महँगा भी</span></Row></Pop></Abs>}
    {t >= 45.73 && <Abs top={900}><Row gap={14}>{['Claude Sonnet', 'Claude Haiku', '+ other models'].map((s, i) => <Pop key={s} at={45.9 + i * 0.25}><span style={{display: 'inline-block', background: '#fff', borderRadius: 30, padding: '12px 24px', fontFamily: SANS, fontWeight: 800, fontSize: 30, boxShadow: '0 10px 22px rgba(60,40,20,0.12)', border: i === 2 ? `2px dashed ${CER}` : 'none'}}>{s}</span></Pop>)}</Row></Abs>}
  </>; };

// ---------- G CTA 48.4–end ----------
const G: React.FC = () => { const t = useT(); const w = type(t, 49.27, 49.8, 'API'); const sent = t >= 50.02;
  return <>
    <Abs top={260}><Pop at={48.52}><Card w={860}><div style={{fontFamily: MONO, fontWeight: 700, fontSize: 20, color: MUTE, letterSpacing: 2}}>COMMENT</div>
      <Row gap={14} style={{marginTop: 10, border: `3px solid ${ROSE}`, borderRadius: 40, padding: '10px 12px 10px 22px'}}><span style={{flex: 1, fontFamily: SANS, fontWeight: 900, fontSize: 56}}>{w}<span style={{opacity: Math.floor(t * 3) % 2 && !sent ? 0 : 1, color: ROSE}}>|</span></span><span style={{background: sent ? GREEN : ROSE, color: '#fff', borderRadius: 30, padding: '10px 26px', fontWeight: 900, fontSize: 28}}>{sent ? 'Sent ✓' : 'Post'}</span></Row></Card></Pop></Abs>
    {sent && <Abs top={520}><Pop at={50.02}><Card w={760}><Row gap={14}><span style={{width: 54, height: 54, borderRadius: 27, background: INK, color: '#fff', fontWeight: 900, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>om</span><b style={{fontSize: 28}}>aiwith.om · DM</b></Row>
      {[[50.02, '🔌 Gateway options'], [51.26, '🪜 Step-by-step setup'], [52.0, '💸 Cost tips']].map(([a, s]) => t >= (a as number) && <Pop key={s as string} at={a as number}><div style={{marginTop: 12, background: '#F9F6F1', borderRadius: 14, padding: '10px 16px', fontSize: 28, fontWeight: 800}}>{s}</div></Pop>)}</Card></Pop></Abs>}
  </>; };

const Caption: React.FC = () => {
  const t = useT();
  const pg = data.pages.find((p) => t >= p.s - 0.05 && t < (p.hold ?? p.s + 3) - 0.05); if (!pg) return null;
  return <div style={{position: 'absolute', top: 1345, left: 70, right: 70, display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '8px 12px', zIndex: 40}}>
    {pg.words.map((w, k) => { if (t < w.s - 0.02) return null; const p = L(t, w.s - 0.02, w.s + 0.1, 0, 1, O3);
      return <span key={k} style={{fontFamily: SANS, fontWeight: 900, fontSize: 52, letterSpacing: -0.5, color: w.hl ? '#fff' : INK, background: w.hl ? (w.hl === 'b' ? CER : ROSE) : 'transparent', borderRadius: 12, padding: w.hl ? '0 12px' : 0, transform: `scale(${0.85 + 0.15 * p})`, display: 'inline-block'}}>{w.w}</span>; })}
  </div>;
};

export const Scenes: React.FC = () => <>
  <LiveBg />
  <Beat a={0} b={3.9}><A /></Beat>
  <Beat a={3.9} b={9.7}><B /></Beat>
  <Beat a={9.7} b={14.6}><C /></Beat>
  <Beat a={14.6} b={34.0}><D /></Beat>
  <Beat a={34.0} b={36.2}><E /></Beat>
  <Beat a={36.2} b={48.4}><F /></Beat>
  <Beat a={48.4} b={99}><G /></Beat>
  <Caption />
</>;
