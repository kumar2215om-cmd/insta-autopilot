# Reel Studio Kit · by @aiwith.om

**Claude Code se poori reel, ek line mein.** Topic do → script (tum approve karo) → voice → word-synced captions → animated scenes → sound design → render → silence cut → 1.1x → self-check contact sheet → caption.

Ye wahi studio hai jisse @aiwith.om ki reels banti hain. Free, MIT licence.

## Chahiye
- [Claude Code](https://claude.com/claude-code) (Claude desktop app ka Code tab ya terminal)
- Node.js 18+, ffmpeg, Python 3.9+
- Voice: ElevenLabs / OpenAI TTS export, ya apni recording (mp3/wav)

## Setup (bina terminal ke)
1. Ye zip unzip karo, folder ka naam rakho `AI Video Editor`.
2. Claude desktop app → **Code** tab → New session → **Local** → ye folder select karo.
3. Claude ko bolo: **`setup check karo`** (wo `setup_check.sh` chalayega aur jo missing hai bata dega).
4. Bolo: **`reel banao: 3 AI tools jo students ka time bachate hain`**
5. Script approve karo, voice file do, aur editor ki tarah bolo: *"hook aur punchy karo"*, *"captions bade karo"*.

## Terminal pasand hai?
```bash
bash setup_check.sh
cd studio && npx remotion studio     # live preview
bash ../render.sh                    # final: deliver/Reel.mp4 + contact_sheet.png
```

## Andar kya hai
| Folder / file | Kya karta hai |
|---|---|
| `.claude/skills/reel-studio/` | Claude Code skill: poora workflow step-by-step |
| `studio/` | Remotion project (1080×1920, 30 fps): scenes, captions, background, logos |
| `studio/seg.py`, `head.py`, `tail.py` | Voice se speech segments + word timings → `data.json` |
| `studio/build_audio.py` | Voice + SFX (whoosh, pop, impact, keys…) + lo-fi music bed, auto-ducked |
| `tools/segs.mjs` | Offline Whisper (free, local): har segment ka text |
| `tools/cut_silence.py` | Saare pauses kaat deta hai (video + audio saath) |
| `render.sh` | Render → −14 LUFS → silence cut → 1.1x → contact sheet |
| `examples/` | 2 finished reels ke scene files (patterns copy karne ke liye) |

## Honest notes
- Pehli baar `npm install` + Whisper model download mein internet aur ~2 GB disk lagta hai.
- Remotion ka apna licence hai: individuals aur chhoti teams (≤3 log) ke liye free; badi company ho to [remotion.dev/license](https://remotion.dev/license) dekho.
- Voice service (ElevenLabs/OpenAI) ki commercial-use terms khud check karo.
- Reel ke facts ki zimmedari tumhari: skill unverified claims flag karta hai, check tum karo.
- Agar Remotion ka browser na chale: `export BROWSER_EXECUTABLE="/path/to/Chrome"`.

Made by **@aiwith.om** · AI Tools & Tips Daily
