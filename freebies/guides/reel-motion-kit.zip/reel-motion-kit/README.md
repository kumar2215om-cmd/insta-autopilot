# Reel Motion Kit · by @aiwith.om

Code se reel animation: na After Effects, na timeline pe drag-drop. 1080×1920, 30 fps, Remotion.
Ye wahi building blocks hain jinse @aiwith.om ki reels animate hoti hain.

## 3 commands
```bash
npm i
npx remotion studio        # browser mein live preview (Demo scene)
npx remotion render src/index.ts Demo out/demo.mp4
```
Node.js 18+ chahiye. "Browser not found" aaye to: `export BROWSER_EXECUTABLE="/path/to/Chrome"`.

## Files
| File | Kya hai |
|---|---|
| `src/brand.ts` | Rang, font, corners, handle: **sirf ye file badlo**, poora look badal jaata hai (2 presets: cream, mint) |
| `src/motion.tsx` | Building blocks: `Beat` `Pop` `Stamp` `Card` `CountUp` `Type` `Cursor` `Punch` `SafeZones` |
| `src/Demo.tsx` | "3 tips" example scene + upar ek `T` timeline (seconds) |

## Timing trick
Har cheez `at={seconds}` pe aati hai. Voice hai to wo second daalo jab wo word bola gaya: hamara **Caption Sync Kit** har word ka time deta hai.

## Safe zones
Instagram upar ~220px, neeche ~380px, right ~120px apne buttons/caption se dhak deta hai. Check karo:
```bash
npx remotion still src/index.ts Demo out/check.png --frame=105 --props='{"debugSafeZones":true}'
```
Laal = Instagram ka UI, hara dabba = safe.

MIT licence · Remotion ka apna licence hai (individuals/≤3 log free; badi company: remotion.dev/license).
