words = []
for pi, (a, b, text) in enumerate(P):
    toks = text.split(); ws = np.array([weight(t) for t in toks])
    edges = a + (b - a) * np.concatenate([[0], np.cumsum(ws) / ws.sum()])
    for i, t in enumerate(toks):
        hl = 'b' if t.startswith('^') else 'o' if t.startswith('*') else ''
        words.append(dict(w=t.lstrip('^*').replace('_', ' '), s=round(float(edges[i]), 3), e=round(float(edges[i + 1]), 3), p=pi, hl=hl))
# one phrase per caption page (reference shows short single lines); long phrase 38 split in two
pages = [[w for w in words if w["p"] == i] for i in range(len(P))]
out = []
for i, pg in enumerate(pages):
    nxt = pages[i + 1][0]['s'] if i + 1 < len(pages) else pg[-1]['e'] + 1.5
    out.append(dict(words=pg, s=pg[0]['s'], hold=round(min(nxt, pg[-1]['e'] + 0.9), 3)))
a, sr = sf.read('vo.wav')
json.dump(dict(pages=out, dur=len(a) / sr), open('src/data.json', 'w'), ensure_ascii=False)
for p in out: print(round(p['s'], 2), ' '.join(w['w'] for w in p['words']))
