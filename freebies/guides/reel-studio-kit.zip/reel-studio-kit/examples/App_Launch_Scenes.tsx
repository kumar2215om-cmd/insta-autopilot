// App_Launch: replica of rahulsingghh Deyxc-WscUu in cream/rose. One continuous funnel (5 platform pipes -> "Your app" tank that
// fills with users) stays on screen; a platform card slides in from the right for each place. No transitions (reference has none).
import React from 'react';
import {AbsoluteFill, useCurrentFrame, spring} from 'remotion';
import '@fontsource/anton/400.css';
import '@fontsource/source-serif-4/600.css';
import {SANS, MONO, FPS, useT} from './kit';
import {L, O3, IO} from './motion';
import {Logo} from './logos';
import {LiveBg} from './LiveBg';
import data from './data.json';

const INK = '#1C1A17', ROSE = '#FF2D95', CER = '#007BA7', MUTE = '#8C8780', GREEN = '#16A34A', RED = '#E5484D', ORG = '#FF6600', PH = '#DA552F';
const DISP = "'Anton', 'Inter', sans-serif", SERIF = "'Source Serif 4', Georgia, serif";
const useSp = (at: number, cfg = {damping: 14, stiffness: 160}) => { const f = useCurrentFrame(); return f < at * FPS ? 0 : spring({frame: f - at * FPS, fps: FPS, config: cfg}); };
const Row: React.FC<{children: React.ReactNode; gap?: number; style?: React.CSSProperties}> = ({children, gap = 12, style}) => <div style={{display: 'flex', alignItems: 'center', gap, ...style}}>{children}</div>;
const Pop: React.FC<{at: number; children: React.ReactNode; style?: React.CSSProperties}> = ({at, children, style}) => { const s = useSp(at); if (s <= 0) return null; return <div style={{transform: `translateY(${(1 - s) * 22}px) scale(${0.8 + 0.2 * s})`, opacity: Math.min(1, s * 2), filter: `blur(${Math.max(0, 1 - s * 1.5) * 8}px)`, ...style}}>{children}</div>; };
const Card: React.FC<{children: React.ReactNode; w?: number; style?: React.CSSProperties}> = ({children, w = 900, style}) => <div style={{width: w, boxSizing: 'border-box', borderRadius: 26, background: '#fff', color: INK, fontFamily: SANS, boxShadow: '0 26px 54px rgba(60,40,20,0.18)', overflow: 'hidden', ...style}}>{children}</div>;
const Bar: React.FC<{w: number | string; c?: string; h?: number}> = ({w, c = '#E9E3D8', h = 14}) => <div style={{width: w, height: h, borderRadius: h / 2, background: c}} />;

// ---------- platforms ----------
const PL = [
  {k: 'reddit', name: 'r/SideProject', at: 6.5, end: 15.3, c: '#FF4500'},
  {k: 'hn', name: 'Hacker News', at: 15.3, end: 22.74, c: ORG},
  {k: 'ph', name: 'Product Hunt', at: 22.74, end: 30.98, c: PH},
  {k: 'ih', name: 'Indie Hackers', at: 30.98, end: 38.37, c: '#0E2439'},
  {k: 'un', name: 'Uneed', at: 38.37, end: 46.84, c: '#111'},
];
const Icon: React.FC<{k: string; s?: number}> = ({k, s = 84}) => {
  const box = (bg: string, ch: React.ReactNode, fg = '#fff', r = 0.26) => <div style={{width: s, height: s, borderRadius: s * r, background: bg, color: fg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: SANS, fontWeight: 900, fontSize: s * 0.5, boxShadow: '0 8px 18px rgba(60,40,20,0.15)'}}>{ch}</div>;
  if (k === 'reddit') return <Logo name="reddit" s={s} />;
  if (k === 'hn') return box(ORG, 'Y');
  if (k === 'ph') return box(PH, 'P', '#fff', 0.5);
  if (k === 'ih') return box('#0E2439', <span style={{fontSize: s * 0.36, letterSpacing: -1}}>IH</span>);
  return box('#fff', <span style={{fontSize: s * 0.42}}>U</span>, INK);
};

// users in the tank over time (follows the VO beats)
const KF: [number, number][] = [[6.5, 0], [10.3, 3], [12.9, 7], [15.3, 8], [17.3, 10], [20.4, 14], [22.7, 16], [24.8, 17], [27.5, 22], [30.9, 24], [33.1, 28], [36.4, 32], [39.3, 33], [43.1, 38], [46.8, 40]];
const users = (t: number) => { if (t < KF[0][0]) return 0; for (let i = 1; i < KF.length; i++) if (t < KF[i][0]) return Math.floor(L(t, KF[i - 1][0], KF[i][0], KF[i - 1][1], KF[i][1])); return 40; };
const PEOPLE = ['#FF2D95', '#007BA7', '#F59E0B', '#16A34A', '#8B5CF6', '#E5484D'];

const XS = [140, 340, 540, 740, 940];
const Funnel: React.FC = () => {
  const t = useT(); const n = users(t);
  const done = PL.filter((p) => t >= p.end).length;
  const full = t >= 46.84;
  return <div style={{position: 'absolute', left: 0, top: 0, width: 1080, height: 560}}>
    <svg width={1080} height={560} style={{position: 'absolute', left: 0, top: 0}}>
      {XS.map((x, i) => { const p = PL[i]; const on = t >= p.at, act = on && t < p.end;
        const d = `M${x} 92 C ${x} 180, ${540 + (x - 540) * 0.25} 170, ${540 + (x - 540) * 0.2} 250 L 540 300`;
        return <g key={i}>
          <path d={d} fill="none" stroke="#E4DACA" strokeWidth={22} strokeLinecap="round" />
          <path d={d} fill="none" stroke={act ? ROSE : on ? CER : '#F3EEE6'} strokeWidth={12} strokeLinecap="round" opacity={on ? 1 : 0.9} />
          {act && <path d={d} fill="none" stroke="#fff" strokeWidth={5} strokeLinecap="round" strokeDasharray="6 26" strokeDashoffset={-t * 120} />}
        </g>; })}
      <path d="M470 290 H610 L590 330 H490 Z" fill="#E4DACA" />
    </svg>
    {XS.map((x, i) => { const on = t >= PL[i].at, act = on && t < PL[i].end; const s = act ? 1 + 0.08 * Math.sin(t * 6) : 1;
      return <div key={i} style={{position: 'absolute', left: x - 42, top: 6, transform: `scale(${s})`, filter: on ? 'none' : 'grayscale(1)', opacity: on ? 1 : 0.4}}><Icon k={PL[i].k} />{t >= PL[i].end && <div style={{position: 'absolute', right: -8, top: -8, width: 30, height: 30, borderRadius: 15, background: GREEN, color: '#fff', fontWeight: 900, fontSize: 18, display: 'flex', alignItems: 'center', justifyContent: 'center', border: '3px solid #fff'}}>✓</div>}</div>; })}
    {/* tank */}
    <div style={{position: 'absolute', left: 290, top: 330, width: 500, height: 190, borderRadius: '18px 18px 34px 34px', background: 'rgba(255,255,255,0.75)', border: `4px solid ${full ? ROSE : '#D9CDB8'}`, boxShadow: full ? '0 0 0 10px rgba(255,45,149,0.12)' : '0 16px 30px rgba(60,40,20,0.1)', overflow: 'hidden'}}>
      <div style={{position: 'absolute', left: 14, right: 14, bottom: 10, display: 'flex', flexWrap: 'wrap-reverse', gap: '4px 6px'}}>
        {Array.from({length: n}).map((_, i) => <svg key={i} width={40} height={40} viewBox="0 0 40 40"><circle cx={20} cy={11} r={8} fill={PEOPLE[i % 6]} /><path d="M6 40 Q6 22 20 22 Q34 22 34 40 Z" fill={PEOPLE[i % 6]} /></svg>)}
      </div>
      {n === 0 && <div style={{position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: MONO, fontSize: 24, color: '#B5A893'}}>· · · empty · · ·</div>}
    </div>
    <div style={{position: 'absolute', left: 40, top: 360, background: '#fff', borderRadius: 18, padding: '12px 18px', boxShadow: '0 12px 26px rgba(60,40,20,0.14)', fontFamily: SANS}}>
      <Row gap={8}><span style={{width: 22, height: 22, borderRadius: 6, background: CER}} /><span style={{fontSize: 22, fontWeight: 700, color: MUTE}}>Your app</span></Row>
      <div style={{fontFamily: DISP, fontSize: 48, color: n === 0 ? RED : INK, lineHeight: 1.1}}>{n} {n === 1 ? 'user' : 'users'}</div>
    </div>
    <div style={{position: 'absolute', right: 40, top: 370, background: '#fff', borderRadius: 18, padding: '12px 16px', boxShadow: '0 12px 26px rgba(60,40,20,0.14)', fontFamily: MONO, fontWeight: 700}}>
      <Row gap={5}>{PL.map((_, i) => <span key={i} style={{width: 20, height: 20, borderRadius: 5, border: `2.5px solid ${i < done ? GREEN : '#CFC4B2'}`, background: i < done ? GREEN : 'transparent'}} />)}</Row>
      <div style={{fontSize: 20, color: MUTE, marginTop: 6}}>{done} of 5 posted</div>
    </div>
    {full && [[260, 320], [820, 330], [300, 500], [790, 490], [540, 300]].map(([x, y], i) => { const p = (t * 1.6 + i * 0.3) % 1; return <div key={i} style={{position: 'absolute', left: x, top: y, fontSize: 34, color: '#F5B83D', transform: `scale(${0.5 + Math.sin(p * Math.PI)})`, opacity: Math.sin(p * Math.PI)}}>✦</div>; })}
  </div>;
};

// card that slides in from the right and out to the left (the reference's card shuffle)
const Slide: React.FC<{a: number; b: number; top?: number; children: React.ReactNode}> = ({a, b, top = 640, children}) => {
  const t = useT(); if (t < a - 0.05 || t > b + 0.4) return null;
  const x = t < b ? L(t, a, a + 0.38, 1080, 0, O3) : L(t, b, b + 0.35, 0, -1080, IO);
  return <div style={{position: 'absolute', top, left: 0, right: 0, display: 'flex', justifyContent: 'center', transform: `translateX(${x}px)`}}>{children}</div>;
};
const Head: React.FC<{n: number; k: string; title: string; sub?: string; bg?: string; fg?: string}> = ({n, k, title, sub, bg = '#F7F3EC', fg = INK}) =>
  <Row gap={16} style={{background: bg, color: fg, padding: '18px 24px'}}><Icon k={k} s={52} /><div style={{flex: 1}}><div style={{fontWeight: 900, fontSize: 32}}>{title}</div>{sub && <div style={{fontSize: 20, opacity: 0.7}}>{sub}</div>}</div><div style={{fontFamily: DISP, fontSize: 44, color: bg === '#F7F3EC' ? ROSE : '#fff', opacity: 0.9}}>0{n}</div></Row>;

// ---------- hook 0–6.3 ----------
const Hook: React.FC = () => { const t = useT(); if (t >= 6.6) return null; const o = L(t, 6.2, 6.5, 1, 0);
  const hl = t >= 4.85;
  return <div style={{position: 'absolute', top: 150, left: 70, right: 70, opacity: o}}><Pop at={0.05}>
    <div style={{background: '#fff', border: `3px solid ${INK}`, boxShadow: `10px 10px 0 ${INK}`, padding: '26px 30px', fontFamily: SERIF, color: INK}}>
      <div style={{fontSize: 62, fontWeight: 600, lineHeight: 1.15}}>App launch किया…{t >= 1.64 && <> कोई <span style={{background: t < 4.85 ? '#FFE4F1' : 'transparent'}}>use नहीं</span> कर रहा?</>}</div>
      {t >= 3.28 && <div style={{fontSize: 62, fontWeight: 600, lineHeight: 1.15, marginTop: 6}}>{t < 4.85 ? <>हर जगह post <span style={{color: RED}}>मत करो।</span></> : <>पहले <span style={{background: hl ? '#FFE14D' : 'transparent', padding: '0 8px'}}>इन 5</span> जगह डालो।</>}</div>}
      <Row gap={8} style={{marginTop: 16, fontFamily: MONO, fontSize: 22, color: MUTE}}>{[0, 1, 2, 3, 4].map((i) => <span key={i} style={{width: 22, height: 22, border: `2.5px solid ${INK}`}} />)}<span style={{marginLeft: 8}}>0 of 5 posted</span></Row>
    </div></Pop></div>;
};
const FunnelPos: React.FC = () => { const t = useT(); const y = L(t, 6.1, 6.6, 620, 90, IO); return <div style={{position: 'absolute', left: 0, top: y, width: 1080}}><div style={{position: 'relative'}}><Funnel /></div></div>; };

// ---------- 1 Reddit ----------
const Reddit: React.FC = () => { const t = useT(); const up = Math.round(L(t, 9.0, 12.9, 1, 124, O3));
  const cm: [number, string, string, string][] = [[12.94, '#F59E0B', 'Onboarding lost me at step 2', '🧐'], [13.6, ROSE, 'Love it. Please add dark mode', '🙏'], [14.2, GREEN, 'Signed up. The streak view is great', '🔥']];
  return <Card><Head n={1} k="reddit" title="r/SideProject" sub="Joined · builders who try new apps" />
    <div style={{padding: '18px 26px 24px'}}>
      <div style={{fontSize: 20, color: MUTE}}>u/you · 2m</div>
      <div style={{fontSize: 34, fontWeight: 800, marginTop: 4}}>I just launched my app, would love some honest feedback</div>
      <div style={{marginTop: 14, height: 150, borderRadius: 16, background: 'linear-gradient(135deg,#7C5CFF,#FF2D95)', padding: 20, boxSizing: 'border-box'}}><Bar w="60%" c="rgba(255,255,255,0.9)" h={18} /><Row gap={10} style={{marginTop: 18}}>{[0, 1, 2].map((i) => <div key={i} style={{flex: 1, height: 60, borderRadius: 12, background: 'rgba(255,255,255,0.85)'}} />)}</Row></div>
      <Row gap={14} style={{marginTop: 14, fontSize: 24, fontWeight: 800}}><span style={{background: t >= 9 ? '#FFE8DD' : '#F3EEE6', color: t >= 9 ? '#FF4500' : MUTE, borderRadius: 20, padding: '6px 16px'}}>▲ {up}</span><span style={{background: '#F3EEE6', borderRadius: 20, padding: '6px 16px', color: MUTE}}>💬 {cm.filter(([a]) => t >= a).length}</span></Row>
      {cm.map(([a, c, s, e]) => t >= a && <Pop key={s} at={a}><Row gap={12} style={{marginTop: 12, background: '#F9F6F1', borderRadius: 14, padding: '10px 14px'}}><span style={{width: 34, height: 34, borderRadius: 17, background: c}} /><span style={{fontSize: 25, fontWeight: 700, flex: 1}}>{s}</span><span style={{fontSize: 28}}>{e}</span></Row></Pop>)}
    </div></Card>; };

// ---------- 2 Hacker News ----------
const HN: React.FC = () => { const t = useT(); const v = Math.round(L(t, 20.36, 22.3, 312, 12480, O3)); const top = t >= 19.18;
  const rows = ['Ask HN: What are you working on?', 'A deep dive into SQLite indexes', 'Why we moved off Kubernetes', 'The quiet death of the RSS reader'];
  const mine = 'Show HN: My app, a tiny habit tracker';
  const typed = t >= 17.33 ? mine.slice(0, Math.round(L(t, 17.33, 18.6, 0, mine.length))) : '';
  const list = top ? [mine, ...rows] : [...rows, mine];
  return <Card><Row gap={14} style={{background: ORG, color: '#fff', padding: '16px 24px'}}><div style={{width: 46, height: 46, border: '3px solid #fff', fontWeight: 900, fontSize: 30, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>Y</div><div style={{flex: 1, fontWeight: 900, fontSize: 32}}>Hacker News <span style={{fontWeight: 600, fontSize: 22}}>new | past | show</span></div><div style={{fontFamily: DISP, fontSize: 44}}>02</div></Row>
    <div style={{padding: '14px 26px 22px', fontFamily: 'Verdana, sans-serif'}}>
      {list.map((r, i) => { const me = r === mine; if (me && t < 17.33) return null;
        return <Row key={r} gap={12} style={{padding: '9px 10px', borderRadius: 10, background: me ? (top ? '#FFF1E6' : '#FBF8F3') : 'transparent', border: me ? `2px solid ${top ? ORG : 'transparent'}` : '2px solid transparent', fontSize: 25}}><span style={{color: MUTE, width: 32}}>{i + 1}.</span><span style={{color: '#999', fontSize: 16}}>▲</span><span style={{fontWeight: me ? 800 : 500, color: INK}}>{me ? typed : r}</span>{me && top && <span style={{marginLeft: 'auto', fontFamily: MONO, fontSize: 16, color: '#fff', background: ORG, borderRadius: 8, padding: '3px 10px'}}>FRONT PAGE</span>}</Row>; })}
      {t >= 20.36 && <Pop at={20.36}><Row style={{marginTop: 14, justifyContent: 'space-between', alignItems: 'flex-end', background: '#F9F6F1', borderRadius: 16, padding: '14px 20px'}}><div><div style={{fontFamily: MONO, fontSize: 18, color: MUTE}}>VISITORS TODAY · example</div><div style={{fontFamily: DISP, fontSize: 64, color: INK}}>{v.toLocaleString('en-US')}</div></div>
        <Row gap={5} style={{alignItems: 'flex-end', height: 90}}>{Array.from({length: 12}).map((_, i) => <div key={i} style={{width: 16, borderRadius: 4, background: ORG, height: 8 + 80 * Math.min(1, L(t, 20.36 + i * 0.1, 20.8 + i * 0.1, 0, 1)) * (0.3 + 0.7 * (i / 11))}} />)}</Row></Row></Pop>}
    </div></Card>; };

// ---------- 3 Product Hunt ----------
const PHc: React.FC = () => { const t = useT(); const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const mid = t >= 24.82, comp = t >= 27.51, wk = t >= 29.73;
  const rank = wk ? 2 : comp ? 7 : 0;
  const rivals: [string, string, number][] = [['Notion habit kit', '#111', 412], ['Pixel icon maker', '#8B5CF6', 391], ['Invoice bot', '#F59E0B', 356], ['Focus radio', CER, 330]];
  return <Card><Head n={3} k="ph" title="Product Hunt" sub="pick your launch day" />
    <div style={{padding: '18px 26px 24px'}}>
      <Row gap={10}>{days.map((d, i) => { const m = mid && !wk && i >= 1 && i <= 3, w = wk && i >= 5;
        return <div key={d} style={{flex: 1, textAlign: 'center', borderRadius: 14, padding: '10px 0', background: m ? '#FFE4F1' : w ? '#E0F2FA' : '#F7F3EC', border: `2.5px solid ${m ? ROSE : w ? CER : 'transparent'}`, fontWeight: 800, fontSize: 22, color: m ? ROSE : w ? CER : MUTE}}>{d}<div style={{fontFamily: DISP, fontSize: 34, color: m || w ? INK : '#C9BFAE'}}>{20 + i}</div></div>; })}</Row>
      {mid && <Pop at={24.82}><div style={{marginTop: 10, textAlign: 'center', fontFamily: MONO, fontWeight: 700, fontSize: 22, color: wk ? CER : ROSE}}>{wk ? 'weekend → lower bar for top 5' : comp ? 'Tue–Thu: most traffic + most competition' : 'Tue–Thu: most traffic'}</div></Pop>}
      <div style={{marginTop: 14}}>
        {(comp ? rivals.slice(0, wk ? 1 : 4) : []).map(([n, c, v], i) => <Row key={n} gap={12} style={{padding: '8px 12px', fontSize: 24}}><span style={{color: MUTE, width: 36}}>#{i + 1}</span><span style={{width: 34, height: 34, borderRadius: 9, background: c}} /><span style={{fontWeight: 700, flex: 1}}>{n}</span><span style={{fontFamily: MONO, color: MUTE}}>▲ {wk ? v - 250 : v}</span></Row>)}
        <Row gap={12} style={{marginTop: 6, padding: '12px 12px', borderRadius: 14, background: rank === 2 ? '#E8F7EE' : '#FFF4EF', border: `2.5px solid ${rank === 2 ? GREEN : PH}`, fontSize: 26}}><span style={{fontWeight: 900, width: 36, color: rank === 2 ? GREEN : PH}}>{rank ? `#${rank}` : '—'}</span><span style={{width: 34, height: 34, borderRadius: 9, background: CER}} /><span style={{fontWeight: 900, flex: 1}}>Your app</span><span style={{fontFamily: MONO, color: INK}}>▲ {Math.round(L(t, 24.82, 30.5, 0, wk ? 181 : 120))}</span></Row>
      </div>
    </div></Card>; };

// ---------- 4 Indie Hackers ----------
const IH: React.FC = () => { const t = useT();
  const posts: [number, string, string, string][] = [[33.13, '@maya', 'building a budgeting app', 'Crossed $1K MRR this week'], [33.6, '@sam', 'building a CRM for gyms', 'Day 30 of building in public'], [34.5, '@you', 'just now', 'I just launched my app. Would you try it?']];
  return <Card><Head n={4} k="ih" title="Indie Hackers" sub="Community · founders building" bg="#0E2439" fg="#fff" />
    <div style={{padding: '14px 24px 24px'}}>
      {posts.map(([a, u, s, p]) => t >= a && <Pop key={u} at={a}><div style={{marginTop: 12, borderRadius: 16, padding: '12px 16px', background: u === '@you' ? '#FFF7FB' : '#F9F6F1', border: `2.5px solid ${u === '@you' ? ROSE : 'transparent'}`}}>
        <Row gap={10}><span style={{width: 36, height: 36, borderRadius: 18, background: u === '@you' ? ROSE : u === '@maya' ? '#F59E0B' : '#8B5CF6'}} /><b style={{fontSize: 24}}>{u}</b><span style={{fontSize: 20, color: MUTE}}>{s}</span></Row>
        <div style={{fontSize: 27, fontWeight: 700, marginTop: 6}}>{p}</div>
        {u === '@you' && t >= 36.4 && <Row gap={10} style={{marginTop: 10}}>{['Tried your app ✓', 'Signed up ✓', 'Feedback sent'].map((x, i) => t >= 36.4 + i * 0.4 && <Pop key={x} at={36.4 + i * 0.4}><span style={{background: '#E8F7EE', color: GREEN, borderRadius: 20, padding: '6px 14px', fontSize: 20, fontWeight: 800}}>{x}</span></Pop>)}</Row>}
      </div></Pop>)}
    </div></Card>; };

// ---------- 5 Uneed ----------
const UN: React.FC = () => { const t = useT();
  const items: [string, string, number][] = [['Notion habit kit', '#111', 88], ['Your app', CER, 74], ['Pixel icon maker', '#8B5CF6', 61], ['Invoice bot', '#F59E0B', 47], ['Focus radio', '#16A34A', 33]];
  return <Card><Head n={5} k="un" title="Uneed" sub="Today's launches" />
    <div style={{padding: '12px 24px 24px'}}>
      {t >= 41.42 && <Pop at={41.42}><Row style={{justifyContent: 'center', marginBottom: 8}}><span style={{fontFamily: MONO, fontWeight: 700, fontSize: 22, background: '#F3EEE6', borderRadius: 20, padding: '6px 16px'}}>only a few launches a day</span></Row></Pop>}
      {items.map(([n, c, v], i) => { const me = n === 'Your app';
        return <Row key={n} gap={12} style={{padding: '9px 12px', marginTop: 4, borderRadius: 14, background: me && t >= 43.09 ? '#E8F7EE' : 'transparent', border: `2.5px solid ${me && t >= 43.09 ? GREEN : 'transparent'}`, fontSize: 25}}><span style={{color: MUTE, width: 40}}>#{i + 1}</span><span style={{width: 36, height: 36, borderRadius: 9, background: c}} /><span style={{fontWeight: me ? 900 : 700, flex: 1}}>{n}</span>{me && t >= 43.09 && <span style={{fontSize: 18, fontWeight: 800, color: GREEN, marginRight: 8}}>not buried ✓</span>}<span style={{fontFamily: MONO, color: MUTE}}>▲ {v}</span></Row>; })}
      {t >= 45.26 && <Pop at={45.26}><Row gap={12} style={{marginTop: 12, background: '#E0F2FA', borderRadius: 14, padding: '12px 16px'}}><span style={{fontSize: 28}}>🔗</span><span style={{fontFamily: MONO, fontWeight: 700, fontSize: 24, color: CER, flex: 1}}>yourapp.com ↗</span><span style={{fontSize: 20, fontWeight: 800, color: CER}}>backlink</span></Row></Pop>}
    </div></Card>; };

// ---------- list + CTA ----------
const List: React.FC = () => { const t = useT();
  return <Card w={860}><Row style={{background: '#F7F3EC', padding: '18px 24px', justifyContent: 'space-between'}}><b style={{fontSize: 32}}>The list</b><span style={{background: GREEN, color: '#fff', borderRadius: 10, padding: '4px 14px', fontWeight: 800, fontSize: 20}}>Free</span></Row>
    <div style={{padding: '8px 24px 18px'}}><div style={{fontWeight: 800, fontSize: 24, color: MUTE, margin: '6px 0'}}>All five launch links</div>
      {PL.map((p, i) => t >= 46.9 + i * 0.12 && <Pop key={p.k} at={46.9 + i * 0.12}><Row gap={14} style={{padding: '7px 0'}}><Icon k={p.k} s={42} /><b style={{fontSize: 26, flex: 1}}>{p.name}</b><span style={{color: GREEN, fontWeight: 900, fontSize: 24}}>✓</span></Row></Pop>)}
    </div></Card>; };
const CTA: React.FC = () => { const t = useT(); const w = 'LAUNCH'.slice(0, Math.round(L(t, 49.0, 49.6, 0, 6))); const sent = t >= 50.09;
  return <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 22}}>
    <Card w={860} style={{padding: '22px 26px'}}><div style={{fontFamily: MONO, fontWeight: 700, fontSize: 20, color: MUTE, letterSpacing: 2}}>COMMENT</div>
      <Row gap={14} style={{marginTop: 10, border: `3px solid ${ROSE}`, borderRadius: 40, padding: '10px 12px 10px 22px'}}><span style={{flex: 1, fontFamily: SANS, fontWeight: 900, fontSize: 52}}>{w}<span style={{opacity: Math.floor(t * 3) % 2 && !sent ? 0 : 1, color: ROSE}}>|</span></span><span style={{background: sent ? GREEN : ROSE, color: '#fff', borderRadius: 30, padding: '10px 26px', fontWeight: 900, fontSize: 28}}>{sent ? 'Sent ✓' : 'Post'}</span></Row></Card>
    {sent && <Pop at={50.09}><Card w={760} style={{padding: '16px 22px'}}><Row gap={14}><span style={{width: 50, height: 50, borderRadius: 25, background: INK, color: '#fff', fontWeight: 900, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>om</span><div><b style={{fontSize: 26}}>aiwith.om · DM</b><div style={{fontSize: 22, color: MUTE}}>5 places to launch your app 🔗</div></div></Row></Card></Pop>}
  </div>; };

const Caption: React.FC = () => {
  const t = useT();
  const pg = data.pages.find((p) => t >= p.s - 0.05 && t < (p.hold ?? p.s + 3) - 0.05); if (!pg) return null;
  return <div style={{position: 'absolute', top: 1345, left: 70, right: 70, display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '8px 12px', zIndex: 40}}>
    {pg.words.map((w, k) => { if (t < w.s - 0.02) return null; const p = L(t, w.s - 0.02, w.s + 0.1, 0, 1, O3);
      return <span key={k} style={{fontFamily: SANS, fontWeight: 900, fontSize: 54, letterSpacing: -0.5, color: w.hl ? '#fff' : INK, background: w.hl ? (w.hl === 'b' ? CER : ROSE) : 'transparent', borderRadius: 12, padding: w.hl ? '0 12px' : 0, transform: `scale(${0.85 + 0.15 * p})`, display: 'inline-block'}}>{w.w}</span>; })}
  </div>;
};

export const Scenes: React.FC = () => <>
  <LiveBg />
  <Hook />
  <FunnelPos />
  <Slide a={6.5} b={15.3}><Reddit /></Slide>
  <Slide a={15.3} b={22.74}><HN /></Slide>
  <Slide a={22.74} b={30.98}><PHc /></Slide>
  <Slide a={30.98} b={38.37}><IH /></Slide>
  <Slide a={38.37} b={46.84}><UN /></Slide>
  <Slide a={46.84} b={48.99}><List /></Slide>
  <Slide a={48.99} b={99}><CTA /></Slide>
  <Caption />
</>;
