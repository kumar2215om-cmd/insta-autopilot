// ⬇️ Sirf ye file badlo: poora template tumhare brand mein aa jaata hai.
export type Brand = {bg: string; card: string; ink: string; mute: string; accent: string; accent2: string; ok: string; font: string; display: string; radius: number; handle: string};
export const PRESETS: Record<string, Brand> = {
  cream: {bg: '#F1EADC', card: '#FFFFFF', ink: '#1C1A17', mute: '#8C8780', accent: '#FF2D95', accent2: '#007BA7', ok: '#16A34A', font: "Inter, sans-serif", display: "Anton, Inter, sans-serif", radius: 26, handle: '@your.handle'},
  mint:  {bg: '#E7F4EE', card: '#FFFFFF', ink: '#0F2A22', mute: '#6B8A7E', accent: '#FF7A1A', accent2: '#0E9F6E', ok: '#0E9F6E', font: "Inter, sans-serif", display: "Anton, Inter, sans-serif", radius: 10, handle: '@your.handle'},
};
export let brand: Brand = PRESETS.cream;
export const useBrand = (name?: string) => (name && PRESETS[name]) || brand;
